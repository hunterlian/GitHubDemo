import json
from pathlib import Path
import pytest

import vault_bridge as vault


def unpack(s):
    return json.loads(s)


def test_new_modify_snapshots_and_full_zip(tmp_path):
    home = str(tmp_path)
    assert unpack(vault.list_vaults(home)) == []
    item = unpack(vault.new_save('票券帳', '16.0.3', home))
    assert item['has_account'] is False
    assert item['needs_initialization'] is True
    vid = item['id']
    prior = unpack(vault.inspect(vid, home))
    assert prior['rare_tickets'] == 0
    assert prior['normal_tickets'] == 0
    edited = unpack(vault.modify_numbers(vid, json.dumps({'rare_tickets': 9999, 'normal_tickets': 9999,
                                                          'catfood': 10000}), home))
    assert edited['backup']
    assert unpack(vault.inspect(vid, home))['rare_tickets'] == 9999
    saved = unpack(vault.backup(vid, '票券帳已修改', home))
    vault.modify_numbers(vid, json.dumps({'rare_tickets': 10}), home)
    assert unpack(vault.inspect(vid, home))['rare_tickets'] == 10
    restored = unpack(vault.restore(vid, saved['id'], home))
    assert restored['safety_backup']
    assert unpack(vault.inspect(vid, home))['rare_tickets'] == 9999
    portable = unpack(vault.export_full_vault(vid, home))
    assert Path(portable['path']).is_file()
    copy = unpack(vault.import_full_vault(portable['path'], '票券帳 2', home))
    assert copy['id'] != vid
    assert unpack(vault.inspect(copy['id'], home))['rare_tickets'] == 9999
    assert len(unpack(vault.list_backups(copy['id'], home))) == 4
    assert len(unpack(vault.list_vaults(home))) == 2


def test_reject_bad_data_without_touching_original(tmp_path):
    home = str(tmp_path)
    item = unpack(vault.new_save('測試', '16.0.3', home))
    vid = item['id']
    original = Path(vault.export_path(vid, True, home)).read_bytes()
    with pytest.raises(ValueError):
        vault.modify_numbers(vid, '{"rare_tickets":10000000}', home)
    with pytest.raises(ValueError):
        vault.rename(vid, '../', home)
    assert Path(vault.export_path(vid, True, home)).read_bytes() == original
    assert unpack(vault.inspect(vid, home))['rare_tickets'] == 0


def test_local_import_and_rename(tmp_path):
    home = str(tmp_path)
    original = unpack(vault.new_save('初始化', '16.0.1', home))
    f = vault.export_path(original['id'], False, home)
    record = unpack(vault.from_file(f, 'JP 版', home))
    assert record['source'] == 'local_file'
    renamed = unpack(vault.rename(record['id'], '獨立存檔', home))
    assert renamed['name'] == '獨立存檔'
