"""Named save vault for BattleCats Lab Android.

Every vault has one immutable initial backup, one working save, and multiple
snapshot files. No transfer secrets are written to metadata or ordinary logs.
"""
from __future__ import annotations

from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import shutil
from tempfile import TemporaryDirectory
from uuid import uuid4

from mobile_bridge import _engine, _home, _bytes, MAX_SAVE_BYTES, VERIFIED

VAULT_ID = re.compile(r"v-[0-9a-f]{24}\Z")
SNAP_ID = re.compile(r"b-[0-9]{8}T[0-9]{6}-[0-9a-f]{8}\Z")


def _utc():
    return datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')


def _name(value):
    if not isinstance(value, str):
        raise ValueError('存檔名稱必須是文字')
    name = value.strip()
    if not 1 <= len(name) <= 40 or any(ord(c) < 32 or c in '\\/' for c in name):
        raise ValueError('名稱請輸入 1～40 字，不可含斜線或控制字元。')
    return name


def _root(home):
    folder = _home(home) / 'vault'
    folder.mkdir(mode=0o700, parents=True, exist_ok=True)
    return folder


def _dir(home, vault_id):
    if not VAULT_ID.fullmatch(vault_id):
        raise ValueError('存檔識別碼不正確。')
    p = _root(home) / vault_id
    if not p.is_dir():
        raise ValueError('找不到指定存檔。')
    return p


def _json(path):
    return json.loads(path.read_text('utf-8'))


def _atomic(path: Path, data: bytes):
    if not 0 < len(data) <= MAX_SAVE_BYTES:
        raise ValueError('存檔大小超出安全限制。')
    temp = path.with_name('.' + path.name + '-' + uuid4().hex + '.part')
    with temp.open('xb') as f:
        f.write(data)
        f.flush(); os.fsync(f.fileno())
    temp.chmod(0o600)
    os.replace(temp, path)


def _metadata(path, meta):
    temp = path.with_name('.meta-' + uuid4().hex + '.tmp')
    temp.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding='utf-8')
    os.replace(temp, path)


def _parse(home, data):
    with _engine(_home(home)) as core:
        s = core.SaveFile(core.Data(data))
        if s.cc.get_code() != 'jp' or s.game_version.to_string() not in VERIFIED:
            raise ValueError('目前只支援 JP 16.0.1、16.0.3 存檔。')
        return {'region': 'jp', 'version': s.game_version.to_string(),
                'has_account': bool(s.inquiry_code), 'catfood': s.catfood,
                'xp': s.xp, 'np': s.np, 'normal_tickets': s.normal_tickets,
                'rare_tickets': s.rare_tickets, 'legend_tickets': s.legend_tickets}


def _create(home, name, payload, source, *, needs_initialization=False):
    name = _name(name)
    info = _parse(home, payload)
    folder = _root(home) / ('v-' + uuid4().hex[:24])
    folder.mkdir(mode=0o700)
    try:
        _atomic(folder / 'original.raw', payload)
        _atomic(folder / 'working.raw', payload)
        (folder / 'snapshots').mkdir(mode=0o700)
        meta = {'id': folder.name, 'name': name, 'source': source,
                'created_at': _utc(), 'updated_at': _utc(),
                'needs_initialization': bool(needs_initialization),
                'account_origin': 'new' if source == 'new' else 'existing',
                'upload_verified': False, 'region': info['region'],
                'version': info['version']}
        _metadata(folder / 'meta.json', meta)
    except BaseException:
        shutil.rmtree(folder, ignore_errors=True)
        raise
    return {'id': folder.name, 'name': name, 'source': source, **info,
            'needs_initialization': bool(needs_initialization)}


def new_save(name, version, home):
    if version not in VERIFIED:
        raise ValueError('目前只支援日版 16.0.1、16.0.3。')
    with _engine(_home(home)) as core:
        save = core.SaveFile(cc=core.CountryCode.from_code('jp'),
                             gv=core.GameVersion.from_string(version))
        payload = save.to_data().to_bytes()
        check = core.SaveFile(core.Data(payload))
        if check.game_version.to_string() != version:
            raise ValueError('空白存檔往返驗證失敗。')
    return json.dumps(_create(home, name, payload, 'new', needs_initialization=True), ensure_ascii=False)


def from_file(path, name, home):
    return json.dumps(_create(home, name, _bytes(Path(path)), 'local_file'), ensure_ascii=False)


def from_cloud(code, pin, version, name, home):
    if version not in VERIFIED or not re.fullmatch(r'[A-Za-z0-9_-]{1,64}', code):
        raise ValueError('版本或引繼碼不符合格式。')
    if not re.fullmatch(r'[0-9]{1,30}', pin):
        raise ValueError('確認碼請輸入數字，開頭 0 也要保留。')
    with _engine(_home(home)) as core:
        handler, _ = core.ServerHandler.from_codes(
            code, pin, core.CountryCode.from_code('jp'),
            core.GameVersion.from_string(version), print=False, save_backup=False)
        if handler is None:
            raise ValueError('伺服器沒有回傳有效的存檔。')
        payload = handler.save_file.to_data().to_bytes()
    return json.dumps(_create(home, name, payload, 'cloud'), ensure_ascii=False)


def list_vaults(home):
    items=[]
    for p in _root(home).iterdir():
        if not p.is_dir() or not VAULT_ID.fullmatch(p.name):
            continue
        try:
            meta = _json(p / 'meta.json')
            count = sum(1 for x in (p / 'snapshots').glob('*.raw') if SNAP_ID.fullmatch(x.stem))
            items.append({'id': p.name, 'name': meta['name'], 'version': meta['version'],
                          'source': meta['source'], 'created_at': meta['created_at'],
                          'updated_at': meta['updated_at'], 'snapshots': count,
                          'needs_initialization': meta.get('needs_initialization', False),
                          'upload_verified': meta.get('upload_verified', False)})
        except (OSError, ValueError, KeyError):
            continue
    items.sort(key=lambda x: x['updated_at'], reverse=True)
    return json.dumps(items, ensure_ascii=False)


def inspect(vault_id, home):
    p=_dir(home,vault_id)
    meta=_json(p/'meta.json')
    info=_parse(home,_bytes(p/'working.raw'))
    info.update({'id':vault_id,'name':meta['name'],
                 'original_sha256':sha256(_bytes(p/'original.raw')).hexdigest(),
                 'working_sha256':sha256(_bytes(p/'working.raw')).hexdigest(),
                 'needs_initialization':meta.get('needs_initialization',False),
                 'upload_verified':meta.get('upload_verified',False),
                 'source':meta['source'],
                 'snapshots':sum(1 for s in (p/'snapshots').glob('*.raw') if SNAP_ID.fullmatch(s.stem))})
    return json.dumps(info,ensure_ascii=False)


def rename(vault_id,name,home):
    p=_dir(home,vault_id);meta=_json(p/'meta.json')
    meta['name']=_name(name);meta['updated_at']=_utc();_metadata(p/'meta.json',meta)
    return json.dumps({'id':vault_id,'name':meta['name']},ensure_ascii=False)


def _snapshot(p,label):
    label=_name(label)
    payload=_bytes(p/'working.raw')
    sid='b-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S')+'-'+uuid4().hex[:8]
    target=p/'snapshots'/f'{sid}.raw'
    _atomic(target,payload)
    _metadata(p/'snapshots'/f'{sid}.json',{'id':sid,'label':label,'created_at':_utc(),
                                                  'sha256':sha256(payload).hexdigest()})
    return sid


def backup(vault_id,label,home):
    p=_dir(home,vault_id)
    sid=_snapshot(p,label)
    meta=_json(p/'meta.json');meta['updated_at']=_utc();_metadata(p/'meta.json',meta)
    return json.dumps({'id':sid,'label':label},ensure_ascii=False)


def list_backups(vault_id,home):
    p=_dir(home,vault_id)
    items=[]
    for file in (p/'snapshots').glob('*.json'):
        if not SNAP_ID.fullmatch(file.stem):continue
        try:
            data=_json(file)
            if (p/'snapshots'/(file.stem+'.raw')).is_file():items.append(data)
        except (OSError,ValueError):pass
    items.sort(key=lambda x:x['created_at'],reverse=True)
    return json.dumps(items,ensure_ascii=False)


def restore(vault_id,backup_id,home):
    p=_dir(home,vault_id)
    if not SNAP_ID.fullmatch(backup_id):raise ValueError('備份編號無效。')
    source=p/'snapshots'/f'{backup_id}.raw'
    selected=_bytes(source)
    expected=_json(p/'meta.json')['version']
    parsed=_parse(home,selected)
    if parsed['version'] != expected:raise ValueError('備份版本不一致。')
    pre=_snapshot(p,'還原前自動備份')
    _atomic(p/'working.raw',selected)
    meta=_json(p/'meta.json');meta['updated_at']=_utc();_metadata(p/'meta.json',meta)
    return json.dumps({'restored':backup_id,'safety_backup':pre},ensure_ascii=False)


FIELD_BOUNDS = {'catfood':999999, 'xp':999999999,'np':999999,
                'normal_tickets':99999,'rare_tickets':99999,'legend_tickets':99999}


def modify_numbers(vault_id, edits_json, home):
    edits=json.loads(edits_json)
    if not isinstance(edits,dict) or not edits:
        raise ValueError('請至少選擇一項修改。')
    for key,value in edits.items():
        if key not in FIELD_BOUNDS or type(value) is not int or not 0<=value<=FIELD_BOUNDS[key]:
            raise ValueError('設定值超出可接受範圍：'+str(key))
    p=_dir(home,vault_id)
    original=_bytes(p/'working.raw')
    with _engine(_home(home)) as core:
        save=core.SaveFile(core.Data(original))
        for key,value in edits.items():setattr(save,key,value)
        updated=save.to_data().to_bytes()
        check=core.SaveFile(core.Data(updated))
        if any(getattr(check,key)!=value for key,value in edits.items()):
            raise ValueError('修改後的驗證失敗，未寫入。')
        if check.inquiry_code!=save.inquiry_code:
            raise ValueError('存檔帳號識別不一致。')
    sid=_snapshot(p,'修改前自動備份')
    _atomic(p/'working.raw',updated)
    meta=_json(p/'meta.json');meta['updated_at']=_utc();meta['upload_verified']=False
    _metadata(p/'meta.json',meta)
    return json.dumps({'backup':sid,'edited':edits,'sha256':sha256(updated).hexdigest()},ensure_ascii=False)


def prepare_talents(vault_id,home):
    p=_dir(home,vault_id)
    data=_bytes(p/'working.raw')
    with _engine(_home(home)) as core:
        from tools import prepare_lab_roster
        save=core.SaveFile(core.Data(data))
        prepare_lab_roster.check_game_data(_home(home)/'game_data',save.game_version.to_string())
        payload,report=prepare_lab_roster.roster_update(save)
        if not report.get('progress_verified'):
            raise ValueError('本能更新結果未通過驗證。')
    sid=_snapshot(p,'全本能修改前自動備份')
    _atomic(p/'working.raw',payload)
    meta=_json(p/'meta.json');meta['updated_at']=_utc();meta['upload_verified']=False
    _metadata(p/'meta.json',meta)
    return json.dumps({'backup':sid,'report':report},ensure_ascii=False)


def export_path(vault_id,original,home):
    p=_dir(home,vault_id)
    return str(p/('original.raw' if original else 'working.raw'))


def upload(vault_id,home):
    """Explicit network operation. Codes are returned only to UI, never logged."""
    p=_dir(home,vault_id)
    meta=_json(p/'meta.json')
    payload=_bytes(p/'working.raw')
    original=_bytes(p/'original.raw')
    before_state=_parse(home,original)
    now_state=_parse(home,payload)
    if before_state['version']!=now_state['version']:
        raise ValueError('版本不一致，禁止上傳。')
    sid=_snapshot(p,'上傳前自動備份')
    with _engine(_home(home)) as core:
        save=core.SaveFile(core.Data(payload))
        start=core.SaveFile(core.Data(original))
        if meta.get('account_origin')=='new' and not save.inquiry_code:
            # A completely new save requires an account actually issued by the game server.
            handler=core.ServerHandler(save,print=False)
            if not handler.create_new_account():
                raise ValueError('官方伺服器未接受新帳號建立，未取得引繼碼。')
        else:
            if not save.inquiry_code or (start.inquiry_code and save.inquiry_code!=start.inquiry_code) or (not start.inquiry_code and meta.get('account_origin')!='new'):
                raise ValueError('此專案的帳號身分與原始備份不符，拒絕上傳。')
            from tools.upload_lab_phone_test import ExistingAccountTransfer
            handler=ExistingAccountTransfer(save,accept_server_account=False)
        codes=handler.get_codes()
        if not codes or len(codes)!=2 or not all(codes):
            raise ValueError('官方伺服器未回傳完整引繼碼，請保留備份並檢查帳號狀態。')
        new_data=save.to_data().to_bytes()
        check=core.SaveFile(core.Data(new_data))
        if not check.inquiry_code:
            raise ValueError('伺服器未建立有效帳號身分。')
    _atomic(p/'working.raw',new_data)
    meta['updated_at']=_utc();meta['upload_verified']=True
    meta['needs_initialization']=False if not meta.get('needs_initialization') else True
    _metadata(p/'meta.json',meta)
    return json.dumps({'transfer_code':codes[0],'confirmation_code':codes[1],
                       'backup':sid,'needs_initialization':meta.get('needs_initialization',False)},ensure_ascii=False)


def export_full_vault(vault_id,home):
    """Create portable ZIP in app-private storage; caller chooses SAF destination."""
    from zipfile import ZipFile, ZIP_DEFLATED
    p=_dir(home,vault_id)
    meta=_json(p/'meta.json')
    export_dir=_home(home)/'exports';export_dir.mkdir(mode=0o700,parents=True,exist_ok=True)
    result=export_dir/('vault-'+vault_id+'-'+uuid4().hex[:8]+'.zip')
    try:
        with ZipFile(result,'w',compression=ZIP_DEFLATED,compresslevel=6) as archive:
            for f in [p/'original.raw',p/'working.raw',p/'meta.json']:
                archive.write(f,f.name)
            for f in (p/'snapshots').iterdir():
                if f.is_file() and SNAP_ID.fullmatch(f.stem) and f.suffix in ('.raw','.json'):
                    archive.write(f,'snapshots/'+f.name)
        if result.stat().st_size>100*1024*1024:
            result.unlink(missing_ok=True);raise ValueError('備份 ZIP 過大。')
    except BaseException:
        result.unlink(missing_ok=True);raise
    return json.dumps({'path':str(result),'filename':meta['name']+'-存檔備份.zip'},ensure_ascii=False)


def import_full_vault(archive_path,name,home):
    """Import only app-generated vault ZIP and create a fresh local vault identity."""
    from zipfile import ZipFile
    archive=Path(archive_path)
    if not archive.is_file() or archive.stat().st_size>100*1024*1024:
        raise ValueError('ZIP 不存在或過大。')
    with ZipFile(archive) as zf:
        names=zf.namelist()
        if not {'original.raw','working.raw','meta.json'}.issubset(names):
            raise ValueError('不是完整的 Lab 存檔備份 ZIP。')
        if len(names)>250 or sum(x.file_size for x in zf.infolist())>200*1024*1024:
            raise ValueError('ZIP 檔案數或容量超出限制。')
        for item in names:
            if item in ('original.raw','working.raw','meta.json'):
                continue
            if not item.startswith('snapshots/') or not SNAP_ID.fullmatch(Path(item).stem) or Path(item).suffix not in ('.raw','.json'):
                raise ValueError('備份 ZIP 包含不支援的內容。')
        original=zf.read('original.raw');working=zf.read('working.raw')
        if len(original)>MAX_SAVE_BYTES or len(working)>MAX_SAVE_BYTES:
            raise ValueError('存檔大小超出限制。')
        old_meta=json.loads(zf.read('meta.json').decode('utf-8'))
        record=_create(home,name,original,'zip_restore',needs_initialization=old_meta.get('needs_initialization',False))
        p=_dir(home,record['id'])
        try:
            w=_parse(home,working)
            if w['version']!=record['version']:
                raise ValueError('ZIP 的工作存檔版本與原始檔不一致。')
            _atomic(p/'working.raw',working)
            for item in names:
                if item.startswith('snapshots/'):
                    data=zf.read(item)
                    if len(data)>MAX_SAVE_BYTES:
                        raise ValueError('快照檔案過大。')
                    _atomic(p/item,data)
            meta=_json(p/'meta.json');meta['upload_verified']=False
            meta['account_origin']=old_meta.get('account_origin','existing')
            _metadata(p/'meta.json',meta)
        except BaseException:
            shutil.rmtree(p,ignore_errors=True);raise
    return json.dumps(record,ensure_ascii=False)
