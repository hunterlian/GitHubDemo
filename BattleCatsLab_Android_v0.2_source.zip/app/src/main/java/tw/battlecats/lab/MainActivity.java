package tw.battlecats.lab;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Self-contained local, named save vault; no default player profiles. */
public class MainActivity extends Activity {
    private static final int LOAD_SAVE = 201, LOAD_CACHE = 202, EXPORT = 203, LOAD_VAULT_ZIP = 204;
    private final ExecutorService tasks = Executors.newSingleThreadExecutor();
    private final List<String> vaultIds = new ArrayList<>();
    private Spinner vaultSpinner, versionSpinner;
    private LinearLayout root;
    private TextView status;
    private String appHome, importName, pendingExportPath, pendingExportName;
    private boolean busy = false;
    private int exportCounter = 0;

    interface ResultCallback { void done(String answer) throws Exception; }
    private int dp(float d) { return Math.round(d * getResources().getDisplayMetrics().density); }
    private LinearLayout.LayoutParams full() { return new LinearLayout.LayoutParams(-1, -2); }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        appHome = new File(getFilesDir(), "lab").getAbsolutePath();
        render();
        refresh();
    }

    private void render() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(17), dp(20), dp(17), dp(40));
        root.setBackgroundColor(Color.rgb(248, 250, 253));
        scroll.addView(root);
        setContentView(scroll);
        heading("貓戰 Lab｜存檔庫 v0.2");
        note("每個存檔是獨立命名專案。修改前自動建立快照；任何上傳都需要明確確認。只操作自己或獲授權的帳號。");
        heading("開始使用");
        note("遊戲版本（目前僅支援 JP 日版）");
        versionSpinner = spinner(new String[]{"JP 16.0.3", "JP 16.0.1"});
        button("＋ 建立新存檔（實驗功能）", () -> askName("建立新存檔", "例如：票券帳", name -> {
            confirm("確認建立空白存檔", "會在本機建立空白存檔。它不是已經註冊的遊戲帳號，也不保證可直接登入官方遊戲。確認後先保存到存檔庫。", () ->
                call("new_save", r -> { show("已建立本機空白存檔：" + new JSONObject(r).getString("name") + "\n尚未通過官方引繼驗證。"); refresh(); },
                    name, selectedVersion(), appHome));
        }));
        button("↓ 舊存檔：從官方引繼下載", this::askCloud);
        button("↓ 舊存檔：從手機選擇檔案", () -> askName("匯入本機存檔", "例如：JP 測試帳", name -> {
            importName = name; chooseFile(LOAD_SAVE);
        }));
        button("↓ 舊存檔：匯入完整 Lab 備份 ZIP", () -> askName("還原 ZIP 到存檔庫", "存檔名稱", name -> {
            importName = name; chooseFile(LOAD_VAULT_ZIP);
        }));
        heading("我的存檔庫");
        note("不用固定『我的／弟弟的』分類；名稱可以自由建立或更改。");
        vaultSpinner = spinner(new String[]{"尚無存檔"});
        button("重新整理存檔庫", this::refresh);
        button("查看目前存檔資訊", this::inspect);
        button("重新命名", () -> { String id = selectedVault(); if (id == null) return;
            askName("重新命名存檔", "新的存檔名稱", name ->
                call("rename", r -> { show("名稱更新成功：" + new JSONObject(r).getString("name")); refresh(); }, id, name, appHome));
        });
        heading("修改工作副本");
        note("數值欄位留空表示不修改，填 0 表示改為 0。每次修改之前都會自動備份，原始存檔永不覆寫。");
        button("修改票券／貓罐頭／XP／NP", this::editNumbers);
        button("套用已有的全本能預設（需要遊戲資料 ZIP）", () -> {
            String id=selectedVault();if(id==null)return;
            confirm("套用已驗證全本能預設", "僅支援已驗證 JP 16.0.x 配置；會先建立還原快照。", () ->
                call("prepare_talents", r -> { show("本能修改副本已建立，修改前快照："+new JSONObject(r).getString("backup")); refresh(); },id,appHome));
        });
        button("匯入已驗證的遊戲資料 ZIP", () -> chooseFile(LOAD_CACHE));
        heading("備份與還原");
        button("＋ 建立命名備份快照", this::askBackup);
        button("查看／還原舊快照", this::showBackups);
        button("匯出目前工作存檔 .raw", () -> exportSave(false));
        button("匯出最初原始存檔 .raw", () -> exportSave(true));
        button("匯出完整存檔庫 ZIP（推薦）", this::exportVaultZip);
        note("完整 ZIP 含存檔與帳號復原相關資料，請自行安全保存。解除安裝 App 前一定要匯出備份。");
        heading("上傳並取得引繼碼");
        note("【實驗功能】新建存檔會嘗試向官方註冊新帳號；舊存檔保留原身分，不會偷偷換帳號。尚未完成 Android 實機端到端測試。");
        button("上傳目前存檔 → 取得引繼碼", this::upload);
        heading("執行結果");
        status = new TextView(this);
        status.setTextSize(14f);
        status.setTextColor(Color.rgb(27, 44, 62));
        status.setTextIsSelectable(true);
        status.setBackgroundColor(Color.WHITE);
        status.setPadding(dp(12), dp(14), dp(12), dp(14));
        status.setText("尚未執行操作");
        root.addView(status, full());
    }

    private void heading(String s) {
        TextView t = new TextView(this);t.setText(s);t.setTextSize(21f);
        t.setTextColor(Color.rgb(24, 65, 104));t.setPadding(0,dp(18),0,dp(9));root.addView(t,full());
    }
    private void note(String s) {
        TextView t=new TextView(this);t.setText(s);t.setTextSize(14f);
        t.setTextColor(Color.rgb(65,73,84));t.setPadding(0,dp(2),0,dp(9));root.addView(t,full());
    }
    private Spinner spinner(String[] items) {
        Spinner s=new Spinner(this);setSpinnerItems(s,items);root.addView(s,full());return s;
    }
    private void setSpinnerItems(Spinner s,String[] items) {
        ArrayAdapter<String> a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,items);
        s.setAdapter(a);
    }
    private void button(String s,Runnable action) {
        Button b=new Button(this);b.setAllCaps(false);b.setText(s);
        LinearLayout.LayoutParams lp=full();lp.topMargin=dp(4);
        root.addView(b,lp);
        b.setOnClickListener(v -> {if(busy) toast("有操作正在進行，請完成後再按");else action.run();});
    }
    private void show(String s) {status.setText(s);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    private String selectedVersion(){return versionSpinner.getSelectedItemPosition()==0?"16.0.3":"16.0.1";}
    private String selectedVault(){int i=vaultSpinner.getSelectedItemPosition();if(i<0||i>=vaultIds.size()){
        toast("先建立或匯入一份存檔");return null;}return vaultIds.get(i);}
    private void confirm(String title,String message,Runnable yes){
        new AlertDialog.Builder(this).setTitle(title).setMessage(message).setNegativeButton("取消",null)
            .setPositiveButton("確認",(dialog,which)->yes.run()).show();
    }
    interface NameCallback{void done(String name);}
    private void askName(String title,String hint,NameCallback callback){
        EditText f=new EditText(this);f.setSingleLine(true);f.setHint(hint);
        LinearLayout box=new LinearLayout(this);box.setPadding(dp(20),0,dp(20),0);box.addView(f,full());
        new AlertDialog.Builder(this).setTitle(title).setView(box).setNegativeButton("取消",null)
            .setPositiveButton("確定",(d,w)->{
                String n=f.getText().toString().trim();if(n.isEmpty())toast("名稱不可留空");else callback.done(n);
            }).show();
    }
    private EditText field(LinearLayout parent,String placeholder,boolean secret){
        EditText f=new EditText(this);f.setSingleLine(true);f.setHint(placeholder);
        if(secret)f.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        parent.addView(f,full());return f;
    }
    private void askCloud(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20),0,dp(20),0);
        EditText name=field(box,"存檔名稱，例如：票券帳",false);
        EditText code=field(box,"官方引繼碼",false);
        EditText pin=field(box,"確認碼（含前導 0）",true);
        new AlertDialog.Builder(this).setTitle("從官方下載舊存檔").setView(box)
            .setNegativeButton("取消",null).setPositiveButton("接收並備份",(d,w)->{
                String n=name.getText().toString().trim(),c=code.getText().toString().trim(),p=pin.getText().toString().trim();
                if(n.isEmpty()||c.isEmpty()||p.isEmpty()){toast("名稱及兩組引繼資訊都必填");return;}
                call("from_cloud",r->{
                    JSONObject obj=new JSONObject(r);
                    show("已接收並建立獨立備份："+obj.getString("name")+"\n版本："+obj.getString("version"));refresh();
                },c,p,selectedVersion(),n,appHome);
            }).show();
    }
    private void runPython(String method,String module,ResultCallback handler,Object... args){
        if(busy)return;
        busy=true;show("正在執行："+method+"\n請勿關閉 App。");
        tasks.execute(()->{
            try {
                String response=Python.getInstance().getModule(module).callAttr(method,args).toString();
                runOnUiThread(()->{busy=false;try{handler.done(response);}catch(Exception e){show("資料解析異常："+e.getMessage());}});
            } catch(Exception error){
                String info=error.getClass().getSimpleName()+"："+String.valueOf(error.getMessage());
                runOnUiThread(()->{busy=false;show("操作未完成："+info);});
            }
        });
    }
    private void call(String method,ResultCallback handler,Object... args){runPython(method,"vault_bridge",handler,args);}
    private void refresh(){
        String previous=selectedVaultQuiet();
        call("list_vaults",r->{
            JSONArray a=new JSONArray(r);vaultIds.clear();List<String> display=new ArrayList<>();
            int pick=0;
            for(int i=0;i<a.length();++i){JSONObject o=a.getJSONObject(i);
                String id=o.getString("id");vaultIds.add(id);
                display.add("📁 "+o.getString("name")+" ｜ JP "+o.optString("version")+" ｜ "+o.optInt("snapshots")+" 備份");
                if(id.equals(previous))pick=i;
            }
            setSpinnerItems(vaultSpinner,display.isEmpty()?new String[]{"尚無存檔"}:display.toArray(new String[0]));
            if(!display.isEmpty())vaultSpinner.setSelection(pick);
            show("存檔庫目前共有 "+a.length()+" 份存檔。\n沒有任何預設帳號或分類。");
        },appHome);
    }
    private String selectedVaultQuiet(){int n=vaultSpinner.getSelectedItemPosition();return n<0||n>=vaultIds.size()?"":vaultIds.get(n);}
    private void inspect(){String id=selectedVault();if(id==null)return;
        call("inspect",r->{JSONObject x=new JSONObject(r);
            show("名稱："+x.optString("name")+"\n來源："+x.optString("source")+
                "\n版本："+x.optString("region")+" "+x.optString("version")+
                "\n罐頭："+x.optString("catfood")+"｜XP："+x.optString("xp")+"｜NP："+x.optString("np")+
                "\n普通券："+x.optString("normal_tickets")+"｜稀有券："+x.optString("rare_tickets")+
                "｜傳說券："+x.optString("legend_tickets")+
                "\n命名備份數："+x.optString("snapshots")+
                "\n官方新帳相容性："+(x.optBoolean("needs_initialization")?"尚待遊戲初始化驗證":"非新建空白存檔")+
                "\n存檔 SHA256："+x.optString("working_sha256"));
        },id,appHome);
    }
    private void editNumbers(){String id=selectedVault();if(id==null)return;
        String[] keys={"catfood","xp","np","normal_tickets","rare_tickets","legend_tickets"};
        String[] names={"貓罐頭","XP","NP","普通券","稀有券","傳說券"};
        LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(dp(20),0,dp(20),0);
        EditText[] fields=new EditText[keys.length];
        for(int i=0;i<fields.length;i++){
            fields[i]=field(form,names[i]+"（留空不變）",false);
            fields[i].setInputType(InputType.TYPE_CLASS_NUMBER);
        }
        ScrollView scroll=new ScrollView(this);scroll.addView(form);
        new AlertDialog.Builder(this).setTitle("修改目前存檔數值").setView(scroll).setNegativeButton("取消",null)
            .setPositiveButton("建立備份並修改",(d,w)->{
                try{
                    JSONObject edits=new JSONObject();
                    for(int i=0;i<fields.length;i++){
                        String value=fields[i].getText().toString().trim();
                        if(!value.isEmpty())edits.put(keys[i],Long.parseLong(value));
                    }
                    if(edits.length()==0){toast("沒有填寫任何修改數值");return;}
                    confirm("確認修改", "即將建立『修改前自動備份』，再修改選取的數值。", () ->
                        call("modify_numbers",r->{JSONObject result=new JSONObject(r);
                            show("修改完成。\n還原點："+result.getString("backup")+"\n修改項目："+result.getJSONObject("edited"));refresh();
                        },id,edits.toString(),appHome));
                }catch(Exception e){show("輸入數值格式錯誤："+e.getMessage());}
            }).show();
    }
    private void askBackup(){String id=selectedVault();if(id==null)return;
        askName("建立命名備份", "例如：票券設定完成",label->
            call("backup",r->{JSONObject j=new JSONObject(r);show("命名備份完成："+j.getString("label"));refresh();},id,label,appHome));
    }
    private void showBackups(){String id=selectedVault();if(id==null)return;
        call("list_backups",r->{
            JSONArray a=new JSONArray(r);if(a.length()==0){show("這份存檔目前沒有命名快照。");return;}
            String[] choices=new String[a.length()];String[] keys=new String[a.length()];
            for(int i=0;i<a.length();i++){
                JSONObject j=a.getJSONObject(i);keys[i]=j.getString("id");
                choices[i]=j.optString("label")+" ｜ "+j.optString("created_at");
            }
            new AlertDialog.Builder(this).setTitle("選擇要還原的快照").setItems(choices,(dialog,index)->{
                String bid=keys[index];
                confirm("確認還原", "將先建立『還原前自動備份』，再把目前工作副本替換成選取的快照。可能恢復較舊的登入資訊。",()->
                    call("restore",answer->{JSONObject j=new JSONObject(answer);show("還原成功。\n還原前保護備份："+j.getString("safety_backup"));refresh();},id,bid,appHome));
            }).setNegativeButton("取消",null).show();
        },id,appHome);
    }
    private void upload(){String id=selectedVault();if(id==null)return;
        confirm("上傳並取得引繼碼（實驗）",
            "此動作會聯繫官方遊戲伺服器。新建空白存檔可能不被接受；舊存檔則沿用原帳號認證。請先匯出完整 ZIP 備份，避免進度遺失。確認繼續？",()->
            call("upload",answer->{JSONObject j=new JSONObject(answer);
                show("官方已回傳引繼資訊；請在遊戲中完成引繼。\n上傳前備份："+j.optString("backup")+
                    (j.optBoolean("needs_initialization")?"\n注意：新建存檔仍需遊戲端初始化驗證。":""));
                showCodes(j.getString("transfer_code"),j.getString("confirmation_code"));
            },id,appHome));
    }
    private void showCodes(String code,String pin){
        TextView t=new TextView(this);t.setText("引繼碼："+code+"\n確認碼："+pin+"\n\n此資訊不會寫入一般操作紀錄。請小心保管。");
        t.setTextIsSelectable(true);t.setTextSize(18f);t.setPadding(dp(20),dp(10),dp(20),dp(10));
        new AlertDialog.Builder(this).setTitle("官方引繼資訊").setView(t)
            .setPositiveButton("關閉",null).setNeutralButton("複製",(d,w)->{
                ClipboardManager cm=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("遊戲引繼資訊","引繼碼："+code+"\n確認碼："+pin));
                toast("已複製；使用後請清除剪貼簿。");
            }).show();
    }
    private void chooseFile(int req){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");
        startActivityForResult(i,req);
    }
    private void exportSave(boolean original){String id=selectedVault();if(id==null)return;
        call("export_path",r->{
            pendingExportPath=r;pendingExportName="BC-Lab-"+id+(original?"-ORIGINAL":"-WORKING")+".raw";
            createDocument(pendingExportName,"application/octet-stream");
        },id,original,appHome);
    }
    private void exportVaultZip(){String id=selectedVault();if(id==null)return;
        call("export_full_vault",r->{
            JSONObject j=new JSONObject(r);pendingExportPath=j.getString("path");pendingExportName=j.getString("filename");
            createDocument(pendingExportName,"application/zip");
        },id,appHome);
    }
    private void createDocument(String name,String mime){
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(mime);i.putExtra(Intent.EXTRA_TITLE,name);startActivityForResult(i,EXPORT);
    }
    @SuppressWarnings("deprecation")
    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data);
        if(result!=RESULT_OK||data==null||data.getData()==null)return;
        final android.net.Uri uri=data.getData();
        if(req==EXPORT){
            if(pendingExportPath==null)return;
            try(InputStream in=new FileInputStream(pendingExportPath);
                OutputStream out=getContentResolver().openOutputStream(uri,"w")){
                if(out==null)throw new IllegalStateException("無法寫入目的檔");
                stream(in,out,120L*1024*1024);
                show("已成功匯出："+pendingExportName+"\n解除安裝前請保存 ZIP。");
            }catch(Exception e){show("匯出失敗："+e.getMessage());}
            finally{pendingExportPath=null;pendingExportName=null;}
            return;
        }
        if(busy){toast("另一項操作進行中，請重新選擇檔案");return;}
        busy=true;show("正在匯入檔案…");
        final int type=req;final String name=importName;
        tasks.execute(()->{
            File tmp=null;
            try{
                tmp=File.createTempFile("vault-import-",type==LOAD_SAVE?".raw":".zip",getCacheDir());
                try(InputStream in=getContentResolver().openInputStream(uri);
                    OutputStream out=new FileOutputStream(tmp)){
                    if(in==null)throw new IllegalStateException("無法讀取選取檔案");
                    stream(in,out,type==LOAD_SAVE?32L*1024*1024:250L*1024*1024);
                }
                String response;
                if(type==LOAD_CACHE){
                    response=Python.getInstance().getModule("mobile_bridge").callAttr("import_game_data_zip",tmp.getAbsolutePath(),appHome).toString();
                }else if(type==LOAD_VAULT_ZIP){
                    response=Python.getInstance().getModule("vault_bridge").callAttr("import_full_vault",tmp.getAbsolutePath(),name,appHome).toString();
                }else{
                    response=Python.getInstance().getModule("vault_bridge").callAttr("from_file",tmp.getAbsolutePath(),name,appHome).toString();
                }
                final String reply=response;
                runOnUiThread(()->{busy=false;show("匯入成功："+reply);refresh();});
            }catch(Exception e){
                String msg=e.getClass().getSimpleName()+"："+e.getMessage();
                runOnUiThread(()->{busy=false;show("匯入失敗："+msg);});
            }finally{if(tmp!=null)tmp.delete();}
        });
    }
    private static void stream(InputStream in,OutputStream out,long maximum)throws Exception{
        byte[] buf=new byte[16384];long size=0;int n;
        while((n=in.read(buf))!=-1){size+=n;if(size>maximum)throw new IllegalArgumentException("檔案超過安全大小限制");out.write(buf,0,n);}
    }
    @Override protected void onDestroy(){tasks.shutdown();super.onDestroy();}
}
