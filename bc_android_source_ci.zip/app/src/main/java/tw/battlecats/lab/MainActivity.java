package tw.battlecats.lab;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Native Android interface. Python core runs locally, without any external relay server. */
public class MainActivity extends Activity {
    private static final int IMPORT_SAVE = 101;
    private static final int IMPORT_CACHE = 102;
    private static final int EXPORT_SAVE = 103;
    private final ExecutorService tasks = Executors.newSingleThreadExecutor();
    private Spinner profile, version, sessions;
    private EditText codeField, pinField;
    private TextView status;
    private final List<String> sessionKeys = new ArrayList<>();
    private String pendingExportPath;
    private String home;
    private boolean busy = false;

    interface ResultHandler { void done(String response) throws Exception; }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        home = new File(getFilesDir(), "lab").getAbsolutePath();
        makeUi();
        profile.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (!busy) refresh();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
        refresh();
    }

    private LinearLayout root;
    private int dp(float n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    private void makeUi() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(24), dp(18), dp(36));
        root.setBackgroundColor(Color.rgb(247, 249, 251));
        scroll.addView(root);
        setContentView(scroll);
        title("貓咪大戰爭｜Lab Android v0.1");
        info("測試版｜只操作本人或獲同意的帳號。所有操作都先存原始備份；需要你手動確認才會上傳。");
        label("帳號分類");
        profile = spinner(new String[]{"我的帳號", "弟弟的帳號"});
        label("遊戲版本（目前只驗證日版）");
        version = spinner(new String[]{"16.0.3", "16.0.1"});
        label("工作階段");
        sessions = spinner(new String[]{"尚無工作階段"});
        button("更新工作階段清單", () -> refresh());
        title("① 接收／匯入");
        info("線上接收使用官方引繼碼＋確認碼。也可以先匯入自己的本機備份測試，不會碰手機內已安裝的遊戲。");
        codeField = new EditText(this);
        codeField.setSingleLine(true);
        codeField.setHint("引繼碼");
        root.addView(codeField, full());
        pinField = new EditText(this);
        pinField.setSingleLine(true);
        pinField.setHint("確認碼（開頭的 0 不可省略）");
        pinField.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        root.addView(pinField, full());
        button("從官方伺服器接收（實驗功能）", () -> {
            String code = codeField.getText().toString().trim();
            String pin = pinField.getText().toString().trim();
            if (code.isEmpty() || pin.isEmpty()) { toast("請輸入兩組引繼資訊"); return; }
            confirm("接收存檔", "確認已取得該帳號主人同意，且已在遊戲中完成引繼準備？接收後只會建立本機備份，不會自動上傳。", () -> {
                call("receive", r -> {
                    JSONObject obj = new JSONObject(r);
                    pinField.setText(""); codeField.setText("");
                    showStatus("已建立接收備份：" + obj.optString("session") + "\n" + obj.optString("version"));
                    refresh();
                }, code, pin, selectedVersion(), selectedProfile(), home);
            });
        });
        button("匯入本機 SAVE_DATA / .raw", () -> openDocument(IMPORT_SAVE));
        title("② 安裝相符的遊戲資料快取");
        info("從 Windows Lab 匯出已驗證的 JP 遊戲資料 ZIP，再用手機選取。不包含在 APK 裡。");
        button("匯入 JP 16.0.x 資料 ZIP", () -> openDocument(IMPORT_CACHE));
        title("③ 查看／修改");
        button("檢查原始存檔", () -> {
            String sid = currentSession(); if (sid == null) return;
            call("inspect", r -> {
                JSONObject j = new JSONObject(r);
                showStatus("版本：" + j.optString("region") + " " + j.optString("version")
                    + "\n貓罐頭：" + j.optString("catfood") + "｜XP：" + j.optString("xp")
                    + "｜NP：" + j.optString("np")
                    + "\n備份 SHA-256：" + j.optString("original_sha256")
                    + "\n修改副本：" + (j.optBoolean("has_edit") ? "有" : "無")
                    + "\n遊戲資料快取：" + (j.optBoolean("game_data_ready") ? "有" : "無"));
            }, sid, selectedProfile(), home);
        });
        button("套用 JP 16.0.x 已驗證全本能預設", () -> {
            String sid = currentSession(); if (sid == null) return;
            confirm("建立修改副本", "僅針對相符 JP 16.0.1 / 16.0.3，沿用 Windows Lab 已驗證的本能預設，不碰原始備份。", () ->
                call("prepare", r -> {
                    JSONObject j = new JSONObject(r);
                    showStatus("修改副本已建立，進度驗證：" + j.optBoolean("progress_verified")
                        + "\n已持有本能角色：" + j.optString("owned_cats_with_talents")
                        + "\n普通本能：" + j.optString("normal_talents_at_max")
                        + "｜超本能：" + j.optString("ultra_talents_at_max"));
                    refresh();
                }, sid, selectedProfile(), home));
        });
        button("匯出原始備份到手機", () -> export(false));
        button("匯出修改副本到手機", () -> export(true));
        title("④ 上傳／還原（請先驗證）");
        info("這兩個功能與官方帳號認證有關，尚未經 Android 實機端到端測試。建議先在測試帳號驗證。引繼資訊只會顯示，不會寫進本機文字日誌。");
        button("上傳修改副本並取得引繼碼（實驗功能）", () -> upload(false));
        button("上傳原始備份以還原（實驗功能）", () -> upload(true));
        title("操作紀錄（不顯示私密引繼碼）");
        status = new TextView(this);
        status.setTextColor(Color.rgb(36, 52, 73));
        status.setTextSize(14f);
        status.setTextIsSelectable(true);
        status.setBackgroundColor(Color.WHITE);
        status.setPadding(dp(12), dp(12), dp(12), dp(12));
        root.addView(status, full());
    }

    private LinearLayout.LayoutParams full() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }
    private void title(String t) {
        TextView v = new TextView(this); v.setText(t); v.setTextSize(20f);
        v.setTextColor(Color.rgb(25, 54, 84)); v.setPadding(0, dp(20), 0, dp(10)); root.addView(v, full());
    }
    private void label(String t) { info(t); }
    private void info(String t) {
        TextView v = new TextView(this); v.setText(t); v.setTextSize(14f);
        v.setTextColor(Color.DKGRAY); v.setPadding(0, dp(4), 0, dp(10)); root.addView(v, full());
    }
    private Spinner spinner(String[] strings) {
        Spinner spinner = new Spinner(this); updateSpinner(spinner, strings);
        root.addView(spinner, full()); return spinner;
    }
    private void updateSpinner(Spinner s, String[] strings) {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, strings);
        s.setAdapter(adapter);
    }
    private void button(String title, Runnable cb) {
        Button b = new Button(this); b.setText(title);
        LinearLayout.LayoutParams lp = full(); lp.topMargin = dp(4);
        root.addView(b, lp); b.setOnClickListener(v -> { if (!busy) cb.run(); else toast("上一項操作尚未結束"); });
    }
    private String selectedProfile() { return profile.getSelectedItemPosition() == 0 ? "mine" : "brother"; }
    private String selectedVersion() { return version.getSelectedItemPosition() == 0 ? "16.0.3" : "16.0.1"; }
    private String currentSession() {
        int n = sessions.getSelectedItemPosition();
        if (n < 0 || n >= sessionKeys.size()) { toast("請先接收或匯入存檔"); return null; }
        return sessionKeys.get(n);
    }
    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }
    private void showStatus(String message) { status.setText(message); }
    private void confirm(String title, String message, Runnable yes) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(message)
            .setNegativeButton("取消", null).setPositiveButton("確認", (d, w) -> yes.run()).show();
    }
    private void call(String name, ResultHandler handler, Object... args) {
        if (busy) return;
        busy = true;
        showStatus("正在執行：" + name + "\n請勿關閉 App 或切換帳號。" );
        tasks.execute(() -> {
            try {
                PyObject bridge = Python.getInstance().getModule("mobile_bridge");
                String result = bridge.callAttr(name, args).toString();
                runOnUiThread(() -> {
                    busy = false;
                    try { handler.done(result); }
                    catch (Exception e) { showStatus("操作回報解析失敗：" + e.getClass().getSimpleName()); }
                });
            } catch (Exception e) {
                String err = e.getClass().getSimpleName() + "：" + String.valueOf(e.getMessage());
                runOnUiThread(() -> { busy = false; showStatus("操作未完成：" + err); });
            }
        });
    }
    private void refresh() {
        String p = selectedProfile();
        // Runs on the same serialized Python executor as save operations.
        call("list_sessions", r -> {
            JSONArray arr = new JSONArray(r); List<String> display = new ArrayList<>();
            sessionKeys.clear();
            for (int i = 0; i < arr.length(); ++i) {
                JSONObject o = arr.getJSONObject(i);
                sessionKeys.add(o.getString("session"));
                display.add(o.getString("session") + " / JP " + o.optString("version")
                    + (o.optBoolean("ready") ? " / 已修改" : " / 未修改"));
            }
            updateSpinner(sessions, display.isEmpty() ? new String[]{"尚無工作階段"} : display.toArray(new String[0]));
            showStatus("已載入 " + arr.length() + " 筆工作階段（" + (p.equals("mine") ? "我的帳號" : "弟弟的帳號") + "）");
        }, p, home);
    }
    private void openDocument(int request) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, request);
    }
    private void export(boolean edited) {
        String sid = currentSession(); if (sid == null) return;
        call("export_path", r -> {
            pendingExportPath = r;
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("application/octet-stream");
            i.putExtra(Intent.EXTRA_TITLE, "BC-Lab-" + sid + (edited ? "-EDITED" : "-BEFORE") + ".raw");
            startActivityForResult(i, EXPORT_SAVE);
        }, sid, selectedProfile(), home, edited);
    }
    private void upload(boolean recover) {
        String sid = currentSession(); if (sid == null) return;
        String p = selectedProfile();
        String text = recover ? "還原原始進度" : "上傳修改副本";
        confirm(text, "這將向遊戲伺服器申請新的引繼碼，可能影響目前的登入狀態。請先備份並確認選對帳號。是否執行？", () ->
            call("upload", r -> {
                JSONObject j = new JSONObject(r);
                showStatus("伺服器已回傳引繼資訊；請完成手機內的引繼。\n（不在此處保存明碼）");
                showCodes(j.getString("transfer_code"), j.getString("confirmation_code"));
            }, sid, p, home, recover, false));
    }
    private void showCodes(String transfer, String pin) {
        TextView t = new TextView(this);
        t.setText("引繼碼：" + transfer + "\n確認碼：" + pin + "\n\n只有本次對話框顯示，請妥善保管。");
        t.setTextSize(18f); t.setTextIsSelectable(true); t.setPadding(dp(20), dp(12), dp(20), dp(12));
        new AlertDialog.Builder(this).setTitle("引繼資訊").setView(t)
            .setPositiveButton("關閉", null)
            .setNeutralButton("複製", (d, w) -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("引繼資訊", "引繼碼: " + transfer + "\n確認碼: " + pin));
                toast("已複製到剪貼簿。請輸入遊戲後清除剪貼簿。");
            }).show();
    }
    @SuppressWarnings("deprecation")
    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        if (req == EXPORT_SAVE) {
            if (pendingExportPath == null) return;
            try (InputStream in = new FileInputStream(pendingExportPath);
                 OutputStream out = getContentResolver().openOutputStream(data.getData(), "w")) {
                if (out == null) throw new IllegalStateException("無法寫入所選檔案");
                transfer(in, out, 32L * 1024 * 1024);
                showStatus("已匯出副本。原始資料仍保留在 App 內。");
            } catch (Exception e) { showStatus("匯出失敗：" + e.getMessage()); }
            finally { pendingExportPath = null; }
            return;
        }
        final int action = req;
        final android.net.Uri uri = data.getData();
        final String p = selectedProfile();
        if (busy) { toast("請先完成目前操作"); return; }
        busy = true;
        showStatus("正在複製所選檔案…");
        tasks.execute(() -> {
            File tmp = null;
            try {
                tmp = File.createTempFile("import-", action == IMPORT_CACHE ? ".zip" : ".raw", getCacheDir());
                try (InputStream in = getContentResolver().openInputStream(uri);
                     OutputStream out = new FileOutputStream(tmp)) {
                    if (in == null) throw new IllegalStateException("無法讀取所選檔案");
                    transfer(in, out, action == IMPORT_CACHE ? 250L * 1024 * 1024 : 32L * 1024 * 1024);
                }
                PyObject bridge = Python.getInstance().getModule("mobile_bridge");
                final String result = action == IMPORT_CACHE
                    ? bridge.callAttr("import_game_data_zip", tmp.getAbsolutePath(), home).toString()
                    : bridge.callAttr("import_save", tmp.getAbsolutePath(), p, home).toString();
                runOnUiThread(() -> {
                    busy = false;
                    showStatus(action == IMPORT_CACHE ? "已驗證並匯入資料快取：" + result : "已匯入原始備份：" + result);
                    refresh();
                });
            } catch (Exception e) {
                String err = e.getClass().getSimpleName() + "：" + e.getMessage();
                runOnUiThread(() -> { busy = false; showStatus("匯入失敗：" + err); });
            } finally { if (tmp != null) tmp.delete(); }
        });
    }
    private void transfer(InputStream in, OutputStream out, long maximum) throws Exception {
        byte[] buf = new byte[8192]; long total = 0; int n;
        while ((n = in.read(buf)) != -1) {
            total += n;
            if (total > maximum) throw new IllegalArgumentException("所選檔案太大");
            out.write(buf, 0, n);
        }
    }
    @Override protected void onDestroy() { tasks.shutdown(); super.onDestroy(); }
}
