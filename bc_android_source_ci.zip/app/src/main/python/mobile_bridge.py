"""BattleCats Lab Android adapter. The original BCSFE code remains GPL-3.0-or-later.

All operations run inside this app's private directory, on files intentionally
selected by the owner. Never automatically syncs or modifies the installed game.
"""
from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import shutil
from tempfile import TemporaryDirectory
from uuid import uuid4
from zipfile import ZipFile

PROFILES = {"mine", "brother"}
VERIFIED = {"16.0.1", "16.0.3"}
SESSION_RE = re.compile(r"s-[0-9]{8}-[0-9a-f]{12}\Z")
MAX_SAVE_BYTES = 32 * 1024 * 1024
MAX_ZIP_BYTES = 250 * 1024 * 1024
MAX_EXTRACTED = 500 * 1024 * 1024
MAX_FILES = 25000


def _home(path: str) -> Path:
    root = Path(path).resolve()
    root.mkdir(mode=0o700, parents=True, exist_ok=True)
    return root


def _profile(root: Path, name: str) -> Path:
    if name not in PROFILES:
        raise ValueError("不支援此帳號分類。")
    p = root / "profiles" / name / "sessions"
    p.mkdir(mode=0o700, parents=True, exist_ok=True)
    return p


def _session(root: Path, profile: str, sid: str) -> Path:
    if not SESSION_RE.fullmatch(sid):
        raise ValueError("工作階段名稱無效。")
    p = _profile(root, profile) / sid
    if not p.is_dir():
        raise ValueError("這個帳號分類找不到指定工作階段。")
    return p


def _write_new(path: Path, payload: bytes) -> None:
    with path.open("xb") as stream:
        stream.write(payload)
    path.chmod(0o600)


def _bytes(path: Path) -> bytes:
    if not path.is_file() or not (0 < path.stat().st_size <= MAX_SAVE_BYTES):
        raise ValueError("存檔不存在，或大小超出安全限制。")
    return path.read_bytes()


@contextmanager
def _engine(root: Path):
    from bcsfe import core
    with TemporaryDirectory(prefix="runtime-", dir=root) as temp:
        folder = Path(temp)
        core.set_data_dir_path(core.Path(str(folder)))
        core.set_config_path(core.Path(str(folder / "config.yaml")))
        core.set_log_path(core.Path(str(folder / "bcsfe.log")))
        core.set_game_data_path(core.Path(str(root / "game_data")))
        core.set_transfer_backup_path(None)
        core.core_data.init_data()
        core.core_data.config[core.ConfigKey.UNLOCK_CAT_ON_EDIT] = False
        core.core_data.config[core.ConfigKey.CLEAR_TUTORIAL_ON_LOAD] = False
        core.core_data.config[core.ConfigKey.REMOVE_BAN_MESSAGE_ON_LOAD] = False
        yield core


def _describe(save) -> dict:
    return {
        "region": save.cc.get_code(),
        "version": save.game_version.to_string(),
        "catfood": save.catfood,
        "xp": save.xp,
        "np": save.np,
        "inquiry": str(save.inquiry_code)[:3] + "***" if save.inquiry_code else "(無)",
    }


def _new_session(root: Path, profile: str, payload: bytes, source: str) -> dict:
    p = _profile(root, profile)
    sid = datetime.now(timezone.utc).strftime("s-%Y%m%d-") + uuid4().hex[:12]
    with _engine(root) as core:
        save = core.SaveFile(core.Data(payload))
        desc = _describe(save)
        if desc["region"] != "jp" or desc["version"] not in VERIFIED:
            raise ValueError("目前驗證範圍只有日版 JP 16.0.1 / 16.0.3。")
    session = p / sid
    session.mkdir(mode=0o700)
    try:
        _write_new(session / "SAVE_DATA_BEFORE", payload)
        (session / "meta.json").write_text(json.dumps({"profile": profile, "source": source, **desc}, ensure_ascii=False), encoding="utf-8")
    except BaseException:
        shutil.rmtree(session, ignore_errors=True)
        raise
    return {"session": sid, "profile": profile, "status": "已備份（未修改）", **desc}


def import_save(source_path: str, profile: str, app_home: str) -> str:
    root = _home(app_home)
    return json.dumps(_new_session(root, profile, _bytes(Path(source_path)), "import"), ensure_ascii=False)


def receive(transfer_code: str, confirmation_code: str, version: str, profile: str, app_home: str) -> str:
    """Experimental network transfer; never auto-uploads after receiving."""
    if version not in VERIFIED:
        raise ValueError("尚未驗證這個遊戲版本。")
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", transfer_code):
        raise ValueError("引繼碼格式無效。")
    if not re.fullmatch(r"[0-9]{1,30}", confirmation_code):
        raise ValueError("確認碼必須是數字（包含前導 0）。")
    root = _home(app_home)
    _profile(root, profile)
    with _engine(root) as core:
        with TemporaryDirectory(prefix="reception-", dir=root) as temp:
            raw = Path(temp) / "received.raw"
            core.set_transfer_backup_path(core.Path(str(raw)))
            handler, _ = core.ServerHandler.from_codes(
                transfer_code, confirmation_code,
                core.CountryCode.from_code("jp"),
                core.GameVersion.from_string(version), print=False,
            )
            if handler is None:
                raise ValueError("伺服器未回傳存檔，請檢查版本及引繼碼。")
            payload = handler.save_file.to_data().to_bytes()
            # The authenticated raw save may include valuable recovery state.
            result = _new_session_after_parsing(root, profile, payload, "receive", core)
            if raw.is_file():
                _write_new(_session(root, profile, result["session"]) / "SAVE_DATA_TRANSFER.raw", _bytes(raw))
            return json.dumps(result, ensure_ascii=False)


def _new_session_after_parsing(root: Path, profile: str, payload: bytes, source: str, core) -> dict:
    """Same as _new_session, without resetting core singleton mid-transfer."""
    save = core.SaveFile(core.Data(payload))
    desc = _describe(save)
    if desc["region"] != "jp" or desc["version"] not in VERIFIED:
        raise ValueError("接收到非支援版本的存檔，未儲存。")
    sid = datetime.now(timezone.utc).strftime("s-%Y%m%d-") + uuid4().hex[:12]
    session = _profile(root, profile) / sid
    session.mkdir(mode=0o700)
    try:
        _write_new(session / "SAVE_DATA_BEFORE", payload)
        (session / "meta.json").write_text(json.dumps({"profile": profile, "source": source, **desc}, ensure_ascii=False), encoding="utf-8")
    except BaseException:
        shutil.rmtree(session, ignore_errors=True)
        raise
    return {"session": sid, "profile": profile, "status": "已接收並備份", **desc}


def list_sessions(profile: str, app_home: str) -> str:
    root = _home(app_home)
    result = []
    for p in sorted(_profile(root, profile).iterdir(), key=lambda f: f.name, reverse=True):
        if not p.is_dir() or not SESSION_RE.fullmatch(p.name):
            continue
        meta = {}
        try:
            meta = json.loads((p / "meta.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            pass
        result.append({"session": p.name, "version": meta.get("version", "?"),
                       "source": meta.get("source", "?"),
                       "ready": (p / "SAVE_DATA_EDITED").is_file(),
                       "backup": (p / "SAVE_DATA_BEFORE").is_file()})
    return json.dumps(result, ensure_ascii=False)


def inspect(session_id: str, profile: str, app_home: str) -> str:
    root = _home(app_home)
    session = _session(root, profile, session_id)
    before = _bytes(session / "SAVE_DATA_BEFORE")
    with _engine(root) as core:
        save = core.SaveFile(core.Data(before))
        desc = _describe(save)
    edited_path = session / "SAVE_DATA_EDITED"
    desc.update(session=session_id, original_sha256=sha256(before).hexdigest(),
                original_bytes=len(before), has_edit=edited_path.is_file(),
                game_data_ready=(root / "game_data" / "jp" / desc["version"] / "downloaded").is_file())
    return json.dumps(desc, ensure_ascii=False)


def import_game_data_zip(archive_path: str, app_home: str) -> str:
    root = _home(app_home)
    archive = Path(archive_path)
    if not archive.is_file() or archive.stat().st_size > MAX_ZIP_BYTES:
        raise ValueError("資料包過大或不存在。")
    with TemporaryDirectory(prefix="cache-", dir=root) as temp:
        staging = Path(temp) / "game_data"
        staging.mkdir()
        count = 0
        total = 0
        versions = set()
        with ZipFile(archive) as zf:
            for member in zf.infolist():
                if member.is_dir():
                    continue
                count += 1
                total += member.file_size
                if count > MAX_FILES or total > MAX_EXTRACTED:
                    raise ValueError("ZIP 的檔案數或解壓縮大小超過限制。")
                path = member.filename
                parts = Path(path).parts
                if (len(parts) < 3 or parts[0] != "jp" or parts[1] not in VERIFIED
                        or ".." in parts or "\\" in path or path.startswith("/")
                        or (member.external_attr >> 16) & 0o170000 == 0o120000):
                    raise ValueError("ZIP 內有非法路徑或不支援的版本。")
                versions.add(parts[1])
                target = staging.joinpath(*parts)
                target.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(member) as source, target.open("xb") as dest:
                    shutil.copyfileobj(source, dest, length=1024*1024)
        if len(versions) != 1:
            raise ValueError("每個 ZIP 只能包含單一個已驗證的 JP 版本。")
        from tools.prepare_lab_roster import check_game_data
        version = versions.pop()
        check_game_data(staging, version=version)
        final = root / "game_data" / "jp" / version
        final.parent.mkdir(parents=True, exist_ok=True)
        if final.exists():
            # Preserve existing validated cache in case the new import is wrong.
            old = root / "cache-rollback"
            if old.exists():
                shutil.rmtree(old)
            final.rename(old)
            try:
                (staging / "jp" / version).rename(final)
            except BaseException:
                old.rename(final)
                raise
            shutil.rmtree(old)
        else:
            (staging / "jp" / version).rename(final)
    return json.dumps({"version": version, "files": count, "verified": True}, ensure_ascii=False)


def prepare(session_id: str, profile: str, app_home: str) -> str:
    root = _home(app_home)
    folder = _session(root, profile, session_id)
    before = _bytes(folder / "SAVE_DATA_BEFORE")
    with _engine(root) as core:
        from tools import prepare_lab_roster
        save = core.SaveFile(core.Data(before))
        prepare_lab_roster.check_game_data(root / "game_data", save.game_version.to_string())
        payload, report = prepare_lab_roster.roster_update(save)
        # Verify that round-trip data preserves everything except intended edits.
        if not report.get("progress_verified"):
            raise ValueError("修改結果未能通過進度驗證。")
        if (folder / "SAVE_DATA_BEFORE").read_bytes() != before:
            raise ValueError("備份在修改期間被變更，操作已取消。")
        edited = folder / "SAVE_DATA_EDITED"
        stage = folder / "SAVE_DATA_EDITED.new"
        _write_new(stage, payload)
        os.replace(stage, edited)
        (folder / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return json.dumps({"session": session_id, "sha256": sha256(payload).hexdigest(), **report}, ensure_ascii=False)


def export_path(session_id: str, profile: str, app_home: str, edited: bool) -> str:
    root = _home(app_home)
    folder = _session(root, profile, session_id)
    filename = "SAVE_DATA_EDITED" if edited else "SAVE_DATA_BEFORE"
    return str(_bytes_path(folder / filename))


def _bytes_path(p: Path) -> Path:
    _bytes(p)
    return p


def upload(session_id: str, profile: str, app_home: str, recover: bool, accept_server_account: bool) -> str:
    """Explicit-only network action. Return codes to UI but never save them."""
    root = _home(app_home)
    folder = _session(root, profile, session_id)
    before = folder / "SAVE_DATA_BEFORE"
    _bytes(before)
    version = json.loads((folder / "meta.json").read_text(encoding="utf-8"))["version"]
    if version not in VERIFIED:
        raise ValueError("不是已驗證版本。")
    from tools import upload_lab_phone_test as transfer
    if recover:
        candidate = folder / "SAVE_DATA_RECOVERY_COPY"
        # A separate copy is needed for recovery so BCSFE can store fresh credentials.
        if not candidate.exists():
            _write_new(candidate, before.read_bytes())
    else:
        report = json.loads((folder / "report.json").read_text(encoding="utf-8"))
        if report.get("progress_verified") is not True:
            raise ValueError("這份修改存檔未通過進度驗證。")
        candidate = folder / "SAVE_DATA_EDITED"
    _bytes(candidate)
    with _engine(root):
        codes = transfer.upload(candidate, before, expected_version=version,
                                restore_original=recover, accept_server_account=accept_server_account)
    if len(codes) != 2:
        raise ValueError("伺服器未回傳完整引繼資訊。")
    return json.dumps({"transfer_code": codes[0], "confirmation_code": codes[1]}, ensure_ascii=False)
