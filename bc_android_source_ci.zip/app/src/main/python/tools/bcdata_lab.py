#!/usr/bin/env python3
"""Build, compare and install JP data packs for the private BCSFE Lab."""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
from pathlib import Path
import re
import shutil
import struct
import sys
import tarfile
import tempfile
from zipfile import BadZipFile, ZipFile


JP_PACKAGE = "jp.co.ponos.battlecats"
JP_SIGNER = "baf876d554213331c6fe5f6bbf9ae9af2f95c20e82b14bc232b0ac3a77680cb1"
APK_BUNDLE_MEMBERS = {
    "xapk": (f"{JP_PACKAGE}.apk", "InstallPack.apk"),
    "apkm": ("base.apk", "split_InstallPack.apk"),
}
ANDROID = "{http://schemas.android.com/apk/res/android}"
PACKS = ("DataLocal", "resLocal")
UNIT_BUY = "DataLocal/unitbuy.csv"
UNIT_LIMIT = "DataLocal/unitlimit.csv"
PICTURE_BOOK = "DataLocal/nyankoPictureBookData.csv"
SKILL_LEVEL = "DataLocal/SkillLevel.csv"
SKILL_ACQUISITION = "DataLocal/SkillAcquisition.csv"
UNIT_TABLES = {UNIT_BUY: 63, UNIT_LIMIT: 2, PICTURE_BOOK: 8}
KEYED_TABLES = {
    SKILL_LEVEL: ["lvID", "lv1"],
    SKILL_ACQUISITION: ["ID", "typeID", "abilityID_A", "MAXLv_A"],
}
REQUIRED_FILES = (
    *UNIT_TABLES,
    *KEYED_TABLES,
    "DataLocal/rankGift.csv",
    "resLocal/SkillDescriptions.csv",
    "resLocal/localizable.tsv",
)
MANIFEST_NAME = "bcdata-lab.json"


def sha256(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write_json(path: Path, content: dict) -> None:
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(content, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def check_version(version: str) -> str:
    if not isinstance(version, str) or not re.fullmatch(
        r"[1-9][0-9]*(?:\.(?:0|[1-9][0-9]?)){2}", version
    ):
        raise ValueError(f"Invalid game version: {version!r}")
    return version


def check_filename(name: str) -> None:
    if (
        not re.fullmatch(r"[a-zA-Z0-9_][a-zA-Z0-9_.-]*", name)
        or name.endswith(".")
        or re.fullmatch(r"CON|PRN|AUX|NUL|COM[0-9]|LPT[0-9]", name.split(".")[0], re.I)
    ):
        raise ValueError(f"Unsupported pack filename: {name!r}")


def copy_zip_member(archive: ZipFile, member: str, destination: Path) -> None:
    if archive.namelist().count(member) != 1:
        raise ValueError(f"Expected exactly one {member} in the ZIP")
    with archive.open(member) as source, destination.open("xb") as output:
        shutil.copyfileobj(source, output)


def find_bundle_members(archive: ZipFile) -> tuple[str, tuple[str, str]]:
    members = archive.namelist()
    layouts = [
        (source_format, pair)
        for source_format, pair in APK_BUNDLE_MEMBERS.items()
        if all(members.count(name) == 1 for name in pair)
    ]
    if len(layouts) != 1:
        raise ValueError("Expected a single base APK and InstallPack pair in an XAPK or APKM bundle")
    return layouts[0]


def signed_apk_manifest(path: Path) -> dict[str, str]:
    import apksigtool
    from apksigcopier import APKSigCopierError
    from pyaxmlparser.axmlprinter import AXMLPrinter

    try:
        _, block = apksigtool.extract_v2_sig(str(path))
        signature = apksigtool.parse_apk_signing_block(block, str(path))
        schemes = [
            pair.value
            for pair in signature.pairs
            if isinstance(pair.value, apksigtool.APKSignatureSchemeBlock)
        ]
        if not schemes or any(not scheme.verified for scheme in schemes):
            raise ValueError("APK content signature did not verify")
        signers = {
            hashlib.sha256(signer.signed_data.certificates[0].data).hexdigest()
            for scheme in schemes
            for signer in scheme.signers
        }
        if signers != {JP_SIGNER}:
            raise ValueError("APK certificate differs from the expected JP signer")
        with ZipFile(path) as apk:
            if apk.namelist().count("AndroidManifest.xml") != 1:
                raise ValueError("Expected one signed AndroidManifest.xml")
            manifest = AXMLPrinter(apk.read("AndroidManifest.xml")).get_xml_obj()
        if manifest is None or manifest.tag != "manifest":
            raise ValueError("Could not parse the signed Android manifest")
        return dict(manifest.attrib)
    except (APKSigCopierError, AssertionError, IndexError, KeyError, struct.error, ValueError) as error:
        raise ValueError(f"{path.name}: {error or 'invalid APK signature block'}") from error


def add_apk_packs(apk_path: Path, version: str, archive_path: Path, temporary: Path) -> None:
    import tbcml

    with ZipFile(apk_path) as apk, tarfile.open(archive_path, "w:xz") as archive:
        for pack_name in PACKS:
            pack_path = temporary / f"{pack_name}.pack"
            copy_zip_member(apk, f"assets/{pack_name}.pack", pack_path)
            list_member = f"assets/{pack_name}.list"
            if apk.namelist().count(list_member) != 1:
                raise ValueError(f"Expected exactly one {list_member} in {apk_path.name}")
            pack = tbcml.PackFile.from_pack_file(
                tbcml.Data(apk.read(list_member)),
                tbcml.Path(str(pack_path)),
                tbcml.CountryCode.JP,
                pack_name,
                tbcml.GameVersion.from_string(version),
            )
            if pack is None or not pack.list_map:
                raise ValueError(f"Unable to read {pack_name}")

            size = pack_path.stat().st_size
            for name, (offset, length) in pack.list_map.items():
                check_filename(name)
                if offset < 0 or length < 0 or offset + length > size:
                    raise ValueError(f"Invalid offset or length for {pack_name}/{name}")

            files = sorted(pack.get_files(), key=lambda entry: entry.file_name)
            for entry in files:
                content = entry.dec_data.to_bytes()
                member = tarfile.TarInfo(f"{pack_name}/{entry.file_name}")
                member.size = len(content)
                member.mode = 0o644
                archive.addfile(member, io.BytesIO(content))


def read_tables(contents: dict[str, bytes]) -> dict[str, dict[int, list[str]]]:
    tables = {}
    for path in (*UNIT_TABLES, *KEYED_TABLES):
        rows = list(csv.reader(io.StringIO(contents[path].decode("utf-8-sig")), strict=True))
        if path in UNIT_TABLES:
            if any(len(row) < UNIT_TABLES[path] for row in rows):
                raise ValueError(f"Short row in {path}")
            tables[path] = dict(enumerate(rows))
            continue

        expected = KEYED_TABLES[path]
        if not rows or rows[0][:len(expected)] != expected:
            raise ValueError(f"Unexpected header in {path}")
        keyed = {}
        for row in rows[1:]:
            if len(row) < 2 or (path == SKILL_ACQUISITION and (len(row) - 2) % 14):
                raise ValueError(f"Unexpected row format in {path}")
            row_id = int(row[0])
            if row_id < 0 or row_id in keyed:
                raise ValueError(f"Invalid or duplicate ID {row_id} in {path}")
            keyed[row_id] = row
        tables[path] = keyed

    unit_count = len(tables[UNIT_BUY])
    if not unit_count or any(len(tables[path]) != unit_count for path in UNIT_TABLES):
        raise ValueError("Unit table row counts do not match")
    if not tables[SKILL_LEVEL] or not tables[SKILL_ACQUISITION]:
        raise ValueError("Talent tables are empty")
    if any(cat_id >= unit_count for cat_id in tables[SKILL_ACQUISITION]):
        raise ValueError("Talent ID refers to a missing unit")
    return tables


def scan_archive(path: Path, destination: Path | None = None) -> tuple[dict, dict, dict]:
    hashes = {}
    required = {}
    names = set()
    counts = dict.fromkeys(PACKS, 0)
    with tarfile.open(path, "r|xz") as archive:
        for member in archive:
            name = member.name.removeprefix("./")
            if member.isdir() and name in (".", *PACKS):
                continue
            pack, slash, filename = name.partition("/")
            if not member.isfile() or not slash or pack not in PACKS:
                raise ValueError(f"Unexpected archive member: {member.name!r}")
            check_filename(filename)
            if name.casefold() in names:
                raise ValueError(f"Duplicate archive path: {name!r}")
            names.add(name.casefold())
            stream = archive.extractfile(member)
            if stream is None:
                raise ValueError(f"Unable to read {name}")
            with stream:
                content = stream.read()
            hashes[name] = hashlib.sha256(content).hexdigest()
            counts[pack] += 1
            if name in REQUIRED_FILES and content:
                required[name] = content
            if destination is not None:
                (destination / pack / filename).write_bytes(content)
    missing = set(REQUIRED_FILES) - required.keys()
    if missing:
        raise ValueError(f"Missing or empty required files: {', '.join(sorted(missing))}")
    return counts, hashes, read_tables(required)


def build(source: Path, version: str, output: Path) -> None:
    version = check_version(version)
    if output.exists() or output.is_symlink():
        raise FileExistsError(f"Build directory already exists: {output}")
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=".bcdata-build-", dir=output.parent) as temp:
        temporary = Path(temp).resolve()
        base_path = temporary / f"{JP_PACKAGE}.apk"
        split_path = temporary / "InstallPack.apk"
        with ZipFile(source) as bundle:
            source_format, (base_member, split_member) = find_bundle_members(bundle)
            copy_zip_member(bundle, base_member, base_path)
            copy_zip_member(bundle, split_member, split_path)

        base = signed_apk_manifest(base_path)
        split = signed_apk_manifest(split_path)
        code = base.get(ANDROID + "versionCode")
        if (
            base.get("package") != JP_PACKAGE
            or base.get("split")
            or base.get(ANDROID + "versionName") != version
            or not code
            or split.get("package") != JP_PACKAGE
            or split.get("split") != "InstallPack"
            or split.get(ANDROID + "versionCode") != code
        ):
            raise ValueError(f"Signed manifests do not identify the same JP {version} release")

        package = temporary / "package"
        package.mkdir()
        archive_path = package / f"jp-{version}.tar.xz"
        add_apk_packs(split_path, version, archive_path, temporary)
        counts, _, _ = scan_archive(archive_path)
        write_json(package / MANIFEST_NAME, {
            "schema": 1,
            "region": "jp",
            "version": version,
            "android_package": JP_PACKAGE,
            "android_version_code": code,
            "signer_sha256": JP_SIGNER,
            f"source_{source_format}_sha256": sha256(source),
            "base_apk_sha256": sha256(base_path),
            "asset_split_sha256": sha256(split_path),
            "archive_sha256": sha256(archive_path),
            "files_by_pack": counts,
        })
        package.rename(output)


def compare(before: dict, after: dict) -> dict:
    common = before.keys() & after.keys()
    return {
        "before_count": len(before),
        "after_count": len(after),
        "added": sorted(after.keys() - before.keys()),
        "removed": sorted(before.keys() - after.keys()),
        "changed": sorted(key for key in common if before[key] != after[key]),
    }


def diff(baseline: Path, candidate: Path) -> dict:
    _, old_hashes, old_tables = scan_archive(baseline)
    _, new_hashes, new_tables = scan_archive(candidate)
    return {
        "baseline": {"file": baseline.name, "sha256": sha256(baseline)},
        "candidate": {"file": candidate.name, "sha256": sha256(candidate)},
        "files": compare(old_hashes, new_hashes),
        "tables": {path: compare(old_tables[path], new_tables[path]) for path in old_tables},
    }


def install(package: Path, lab_root: Path) -> Path:
    manifest = json.loads((package / MANIFEST_NAME).read_text(encoding="utf-8"))
    if (
        not isinstance(manifest, dict)
        or manifest.get("schema") != 1
        or manifest.get("region") != "jp"
        or manifest.get("android_package") != JP_PACKAGE
        or manifest.get("signer_sha256") != JP_SIGNER
    ):
        raise ValueError("Unsupported or invalid BCData-Lab manifest")
    version = check_version(manifest.get("version"))
    archive = package / f"jp-{version}.tar.xz"
    if sha256(archive) != manifest.get("archive_sha256"):
        raise ValueError("Archive SHA-256 differs from the build manifest")

    lab_root = lab_root.resolve(strict=True)
    if lab_root.name.casefold() != "bcsfe-lab" or not (lab_root / "appdata").is_dir():
        raise ValueError("Expected a BCSFE-Lab root with an appdata directory")
    cache = lab_root / "appdata" / "game_data" / "jp"
    if cache.resolve() != cache:
        raise ValueError("Lab game-data cache resolves outside its configured path")
    target = cache / version
    if target.exists() or target.is_symlink():
        raise FileExistsError(f"Version is already present: {target}")
    cache.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=".bcdata-install-", dir=cache) as temp:
        staged = Path(temp) / version
        for pack in PACKS:
            (staged / pack).mkdir(parents=True)
        counts, _, _ = scan_archive(archive, staged)
        if counts != manifest.get("files_by_pack"):
            raise ValueError("Archive file counts differ from the build manifest")
        write_json(staged / MANIFEST_NAME, manifest)
        (staged / "downloaded").touch()
        staged.rename(target)
    return target


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    build_parser = commands.add_parser("build", help="verify and unpack a local JP XAPK or APKM")
    build_parser.add_argument("bundle", type=Path)
    build_parser.add_argument("output", type=Path, help="new build directory")
    build_parser.add_argument("--version", required=True)
    diff_parser = commands.add_parser("diff", help="compare two BCData .tar.xz packs")
    diff_parser.add_argument("baseline", type=Path)
    diff_parser.add_argument("candidate", type=Path)
    diff_parser.add_argument("--output", type=Path, help="new JSON report file")
    install_parser = commands.add_parser("install", help="install a verified build into Lab's JP cache")
    install_parser.add_argument("build", type=Path)
    install_parser.add_argument("--lab-root", type=Path, default=Path.home() / "Documents" / "BCSFE-Lab")
    args = parser.parse_args()

    try:
        if args.command == "build":
            build(args.bundle, args.version, args.output)
            print(args.output)
        elif args.command == "diff":
            report = diff(args.baseline, args.candidate)
            if args.output is None:
                print(json.dumps(report, ensure_ascii=False, indent=2))
            else:
                write_json(args.output, report)
        else:
            print(install(args.build, args.lab_root))
    except ImportError:
        print("Build requires tools/bcdata-requirements.txt in its Python environment.", file=sys.stderr)
        return 1
    except (OSError, ValueError, csv.Error, tarfile.TarError, BadZipFile) as error:
        print(f"BCData Lab: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
