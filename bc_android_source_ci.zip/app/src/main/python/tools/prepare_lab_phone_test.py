#!/usr/bin/env python3
"""Reapply the verified JP 16.0.1 cat edits to a local phone backup copy."""

from __future__ import annotations

import argparse
from copy import deepcopy
import json
from pathlib import Path
from tempfile import TemporaryDirectory

from bcsfe import core


LEVELS = {882: 50, 883: 50, 884: 50, 885: 50, 886: 60}
DROP_FLAGS = {882: 306, 883: 307, 884: 308, 885: 309}
TALENTS = {
    241: {2: 10, 15: 10, 31: 10, 32: 10, 49: 1},
    358: {56: 10, 71: 5, 73: 1},
    660: {11: 10, 31: 10, 32: 10, 44: 1, 48: 1},
}
LEVEL_FIELDS = ("unlocked", "gatya_seen", "upgrade", "max_upgrade_level", "catseyes_used")


def read_save(path: Path) -> core.SaveFile:
    return core.SaveFile(core.Data(path.read_bytes()))


def state_without_transfer_credentials(save: core.SaveFile) -> dict:
    state = save.to_dict()
    state.pop("password_refresh_token")
    prefix = core.SaveFile.get_string_identifier(core.ServerHandler.get_password_key()) + ":"
    state["order_ids"] = [entry for entry in state["order_ids"] if not entry.startswith(prefix)]
    return state


def get_source(backup: Path, received: Path | None) -> tuple[core.SaveFile, Path]:
    raw_save = read_save(backup)
    candidates = (received,) if received is not None else (
        backup.with_suffix(""), backup.parent / "SAVE_DATA"
    )
    for candidate in candidates:
        if received is None and (
            not candidate.is_file() or candidate.samefile(backup)
            or candidate.stat().st_mtime_ns < backup.stat().st_mtime_ns
        ):
            continue
        try:
            saved = read_save(candidate)
        except (OSError, UnicodeError, core.SaveError):
            if received is not None:
                raise
            continue
        if state_without_transfer_credentials(saved) == state_without_transfer_credentials(raw_save):
            return saved, candidate
        if received is not None:
            raise ValueError("The selected downloaded file does not match the phone backup.")
    return raw_save, backup


def check_cache(game_data: Path, *, version: str = "16.0.1", max_new_cats: bool = False) -> None:
    version_root = game_data / "jp" / version
    required = (
        "downloaded", "DataLocal/unitbuy.csv", "DataLocal/unitlimit.csv",
        "DataLocal/rankGift.csv", "DataLocal/drop_chara.csv",
    )
    if not max_new_cats:
        required += (
            "DataLocal/nyankoPictureBookData.csv", "DataLocal/SkillLevel.csv",
            "DataLocal/SkillAcquisition.csv", "resLocal/SkillDescriptions.csv",
        )
    for name in required:
        if not (version_root / name).is_file():
            raise ValueError(f"JP {version} cache is missing {name}.")


def unlock_new_cat(save: core.SaveFile, cat: core.Cat, expected: dict) -> None:
    if len(save.menu_unlocks) < 3:
        raise ValueError("Missing the equipment menu flag in the phone backup.")
    drops = core.core_data.get_chara_drop(save)
    if drops.drops is None:
        raise ValueError("Cannot read the JP character drop table.")
    drop_ids = {drop.save_id for drop in drops.get_drops_from_chara_id(cat.id) or []}
    expected_drop_ids = {DROP_FLAGS[cat.id]} if cat.id in DROP_FLAGS else set()
    if drop_ids != expected_drop_ids or any(index >= len(save.unit_drops) for index in drop_ids):
        raise ValueError(f"Cat {cat.id}: unexpected character drop flag.")
    for index in drop_ids:
        expected["unit_drops"][index] = 1
    expected["menu_unlocks"][2] = max(expected["menu_unlocks"][2], 1)
    cat.unlock(save)


def apply_verified_forms_and_talents(
    save: core.SaveFile, cats: dict[int, core.Cat], expected_cats: dict[int, dict]
) -> None:
    califa = cats[159]
    form_data = save.cats.read_unitbuy(save).get_unit_buy(159)
    if form_data is None or not califa.unlocked or califa.upgrade.get_base() < form_data.evolve_level_ff:
        raise ValueError("Cat 159: the fourth form requires an unlocked cat at Lv.60.")
    if save.cats.fourth_form_cats(save, [califa]) != 1:
        raise ValueError("Cat 159: the JP picture book did not confirm the fourth form.")
    expected_cats[159].update(current_form=3, unlocked_forms=3, fourth_form=2)

    talent_data = save.cats.read_talent_data(save)
    if talent_data is None:
        raise ValueError("Cannot read JP talent data.")
    for cat_id, targets in TALENTS.items():
        cat = cats[cat_id]
        data = talent_data.get_cat_talents(cat)
        if not cat.unlocked or data is None:
            raise ValueError(f"Cat {cat_id}: missing the unlocked cat or talent slots.")
        _, max_levels, _, ids = data
        caps = dict(zip(ids, max_levels))
        for talent in expected_cats[cat_id]["talents"]:
            ability_id = talent["id"]
            if ability_id in targets:
                talent["level"] = targets[ability_id]
        for ability_id, level in targets.items():
            slot = cat.get_talent_from_id(ability_id)
            if slot is None or caps.get(ability_id) != level:
                raise ValueError(f"Cat {cat_id}: missing slot or unexpected cap for talent {ability_id}.")
            slot.level = level


def apply_edits(
    save: core.SaveFile, *, version: str = "16.0.1", max_new_cats: bool = False,
) -> tuple[bytes, dict]:
    if (save.cc.get_code(), save.game_version.to_string()) != ("jp", version):
        raise ValueError(f"Select a JP {version} save.")
    before = deepcopy(save.to_dict())
    expected = deepcopy(before)
    expected_cats = {cat["id"]: cat for cat in expected["cats"]["cats"]}
    ids = set(LEVELS) if max_new_cats else {159, *LEVELS, *TALENTS}
    cats = {cat.id: cat for cat in save.cats.get_cats_by_ids(list(ids))}
    if cats.keys() != ids:
        raise ValueError("Missing cat records in the phone backup.")

    unit_buy = save.cats.read_unitbuy(save)
    for cat_id, level in LEVELS.items():
        cat = cats[cat_id]
        cap = unit_buy.get_unit_buy(cat_id)
        if cap is None or cap.max_upgrade_level_catseye != level:
            raise ValueError(f"Cat {cat_id}: unexpected JP {version} base cap.")
        if not max_new_cats or not cat.unlocked:
            unlock_new_cat(save, cat, expected)
        if cat.upgrade.get_base() != level:
            power_up = core.PowerUpHelper(cat, save)
            power_up.reset_upgrade()
            power_up.upgrade_by(level - 1)
        if cat.upgrade.get_base() != level:
            raise ValueError(f"Cat {cat_id}: could not reach Lv.{level} with the save's upgrade data.")
        plus_cap = max(0, cap.max_plus_upgrade_level)
        cat.upgrade.plus = plus_cap if max_new_cats else min(cat.upgrade.plus, plus_cap)
        edited = cat.serialize()
        expected_cats[cat_id].update({key: edited[key] for key in LEVEL_FIELDS})

    if not max_new_cats:
        apply_verified_forms_and_talents(save, cats, expected_cats)

    payload = save.to_data().to_bytes()
    roundtrip = core.SaveFile(core.Data(payload)).to_dict()
    if roundtrip != expected:
        unexpected = sorted(key for key in expected if roundtrip.get(key) != expected[key])
        raise ValueError(f"The round trip changed unexpected fields: {', '.join(unexpected)}.")
    report = {
        "changed_save_fields": sorted(key for key in before if key != "cats" and before[key] != expected[key]),
        "new_cat_levels": {cat_id: f"{cats[cat_id].upgrade.get_base()}+{cats[cat_id].upgrade.plus}" for cat_id in LEVELS},
    }
    if max_new_cats:
        changed_cats = {}
        for cat in before["cats"]["cats"]:
            updated = expected_cats[cat["id"]]
            if cat != updated:
                changed_cats[cat["id"]] = [key for key in cat if cat[key] != updated[key]]
        report["changed_cat_fields"] = changed_cats
    else:
        report["fourth_form"] = {"id": 159, "current_form": 4, "flag": 2}
        report["verified_talent_levels"] = TALENTS
    return payload, report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("backup", type=Path, help="raw phone backup or existing Lab test copy")
    parser.add_argument("--lab-root", type=Path, required=True)
    parser.add_argument("--received", type=Path, help="separately saved download from the same reception")
    parser.add_argument("--output", type=Path, help="new output file (default: next to the backup)")
    parser.add_argument("--max-new-cats", action="store_true", help="apply max+max to IDs 882-886 only")
    args = parser.parse_args()
    game_data = args.lab_root / "appdata" / "game_data"
    suffix = "_LAB_PHONE_MAX" if args.max_new_cats else "_LAB_PHONE_TEST"
    output = args.output or args.backup.with_name(args.backup.stem + suffix)

    try:
        check_cache(game_data, max_new_cats=args.max_new_cats)
        with TemporaryDirectory(prefix="bcsfe-lab-phone-") as temp:
            core.set_data_dir_path(core.Path(temp))
            core.set_config_path(core.Path(str(Path(temp) / "config.yaml")))
            core.set_log_path(core.Path(str(Path(temp) / "bcsfe.log")))
            core.set_game_data_path(core.Path(str(game_data)))
            core.core_data.init_data()
            core.core_data.config[core.ConfigKey.UNLOCK_CAT_ON_EDIT] = False
            save, source = get_source(args.backup, args.received)
            payload, report = apply_edits(save, max_new_cats=args.max_new_cats)
        try:
            file = output.open("xb")
        except FileExistsError:
            if output.samefile(args.backup) or output.samefile(source) or output.read_bytes() != payload:
                raise
        else:
            try:
                with file:
                    file.write(payload)
            except OSError:
                output.unlink(missing_ok=True)
                raise
    except (OSError, UnicodeError, core.SaveError, ValueError) as error:
        parser.exit(1, f"BCSFE Lab: {error}\n")
    source_kind = "raw" if args.backup.suffix == ".raw" else "input"
    if source != args.backup:
        source_kind = "received"
    print(json.dumps({"output": str(output), "source": source_kind, **report}, indent=2))


if __name__ == "__main__":
    main()
