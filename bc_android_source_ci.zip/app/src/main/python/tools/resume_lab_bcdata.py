#!/usr/bin/env python3
"""Build and install verified JP data in an existing BCSFE Lab."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import tempfile
from urllib.error import URLError
from urllib.request import Request, urlopen

if __package__:
    from . import bcdata_lab
else:
    import bcdata_lab


VERSION = "16.0.1"
XAPK_RELEASES = {
    "16.0.1": ("1600010", "f2e593ed4b84aafde240420fe59286aaacc0813cd93021e182067f9153240a51"),
    "16.0.3": ("1600030", "56b487c5c0c61a64344fb89198e86fd794aa2ef7219ea6e95b9c5dbb2e0bc1b6"),
}
# Digest of the sorted file paths and their SHA-256 digests from the signed release.
# This also verifies archives produced with a different XZ encoder.
SHARED_PACKS = {
    "16.0.3": ("16.0.1", "0af981536197d87be1d4318fceab589181aeb4b499745ccf4a747367b3f13db7"),
}


def download_xapk(work: Path, version: str) -> Path:
    version_code, expected_hash = XAPK_RELEASES[version]
    target = work / f"jp-{version}.xapk"
    if target.is_file():
        if bcdata_lab.sha256(target) != expected_hash:
            raise ValueError(
                f"Unexpected XAPK checksum at {target}. Pass a verified bundle with --bundle."
            )
        return target

    print(f"Downloading JP {version} XAPK from APKPure.net...", flush=True)
    url = f"https://d.apkpure.net/b/XAPK/{bcdata_lab.JP_PACKAGE}?versionCode={version_code}"
    request = Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36",
        "Referer": "https://apkpure.net/",
    })
    with tempfile.TemporaryDirectory(prefix=".bcdata-download-", dir=work) as temp:
        staged = Path(temp) / target.name
        try:
            with urlopen(request, timeout=45) as response, staged.open("xb") as file:
                shutil.copyfileobj(response, file)
        except (URLError, TimeoutError) as error:
            raise ValueError(
                f"APKPure.net download failed ({error}). Run again with --bundle and an APKMirror APKM."
            ) from error
        if bcdata_lab.sha256(staged) != expected_hash:
            raise ValueError("Downloaded XAPK checksum differs from the verified release. Use --bundle with the APKM.")
        staged.rename(target)
    return target


def reuse_verified_archive(work: Path, output: Path, version: str) -> bool:
    shared = SHARED_PACKS.get(version)
    if shared is None:
        return False
    previous, expected_hash = shared
    previous_archive = work / f"jp-{previous}" / f"jp-{previous}.tar.xz"
    if not previous_archive.is_file():
        return False

    with tempfile.TemporaryDirectory(prefix=".bcdata-reuse-", dir=work) as temp:
        package = Path(temp) / "package"
        package.mkdir()
        archive = package / f"jp-{version}.tar.xz"
        shutil.copyfile(previous_archive, archive)
        try:
            counts, hashes, _ = bcdata_lab.scan_archive(archive)
        except (tarfile.TarError, ValueError):
            return False
        file_index = json.dumps(hashes, sort_keys=True, separators=(",", ":")).encode("ascii")
        if hashlib.sha256(file_index).hexdigest() != expected_hash:
            return False

        provenance = Path(__file__).resolve().parents[1] / "docs" / "lab" / f"JP-{version}-provenance.json"
        manifest = json.loads(provenance.read_text(encoding="utf-8"))
        manifest.update(
            archive_sha256=bcdata_lab.sha256(archive),
            files_by_pack=counts,
            reused_archive_from=previous,
            pack_contents_sha256=expected_hash,
        )
        bcdata_lab.write_json(package / bcdata_lab.MANIFEST_NAME, manifest)
        package.rename(output)
    print(f"Local JP {previous} data verified against the signed JP {version} release.", flush=True)
    return True


def build_with_lab_venv(lab: Path, source: Path, output: Path, version: str) -> None:
    env = lab / ".bcdata-venv"
    builder = env / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    if not builder.is_file():
        subprocess.run([sys.executable, "-m", "venv", str(env)], check=True)

    dependencies = subprocess.run(
        [str(builder), "-c", "import tbcml, apksigtool, apksigcopier, pyaxmlparser"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    if dependencies.returncode:
        if shutil.which("git") is None:
            raise ValueError("Git is needed for the first BCData build. Install Git for Windows and retry.")
        requirements = Path(__file__).with_name("bcdata-requirements.txt")
        subprocess.run([str(builder), "-m", "pip", "install", "-r", str(requirements)], check=True)

    tool = Path(bcdata_lab.__file__).resolve()
    print(f"Verifying signed APKs and building JP {version} data...", flush=True)
    subprocess.run(
        [str(builder), str(tool), "build", str(source), str(output), "--version", version],
        check=True,
    )


def resume(lab: Path, source: Path | None, *, version: str = VERSION) -> dict:
    if lab.name.casefold() != "bcsfe-lab" or not (lab / "appdata").is_dir():
        raise ValueError("Expected the existing BCSFE-Lab directory with appdata")
    if version not in XAPK_RELEASES:
        raise ValueError(f"No verified JP {version} release is configured")

    cache = lab / "appdata" / "game_data" / "jp" / version
    manifest = cache / bcdata_lab.MANIFEST_NAME
    if not manifest.is_file():
        work = lab / "bcdata-work"
        work.mkdir(exist_ok=True)
        build = work / f"jp-{version}"
        if not (build / bcdata_lab.MANIFEST_NAME).is_file():
            if source is not None:
                build_with_lab_venv(lab, source.resolve(strict=True), build, version)
            elif not reuse_verified_archive(work, build, version):
                build_with_lab_venv(lab, download_xapk(work, version), build, version)
        bcdata_lab.install(build, lab)

    data = json.loads(manifest.read_text(encoding="utf-8"))
    if (
        not isinstance(data, dict)
        or data.get("region") != "jp"
        or data.get("version") != version
        or not (cache / "downloaded").is_file()
    ):
        raise ValueError(f"Incomplete or unexpected JP cache at {cache}")
    return data


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lab-root", type=Path, default=Path.home() / "Documents" / "BCSFE-Lab")
    parser.add_argument("--version", choices=XAPK_RELEASES, default=VERSION)
    parser.add_argument("--bundle", type=Path, help="use an already downloaded XAPK or APKM")
    args = parser.parse_args()
    try:
        data = resume(args.lab_root.resolve(strict=True), args.bundle, version=args.version)
        counts = data["files_by_pack"]
        print(f"BCData jp {args.version} | DataLocal {counts['DataLocal']} | resLocal {counts['resLocal']}")
    except (OSError, ValueError, subprocess.CalledProcessError) as error:
        parser.exit(1, f"BCData Lab: {error}\n")


if __name__ == "__main__":
    main()
