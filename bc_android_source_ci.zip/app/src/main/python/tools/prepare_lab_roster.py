#!/usr/bin/env python3
"""Prepare and verify a JP roster update from one player's own save."""

from __future__ import annotations

import argparse
from collections import Counter
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
from tempfile import TemporaryDirectory, mkdtemp
from zipfile import BadZipFile

from bcsfe import core
from bcsfe.core.game.catbase.cat import Talent
from tools import prepare_lab_phone_test as phone
from tools import resume_lab_bcdata
from tools import upload_lab_phone_test as transfer


VERSION = resume_lab_bcdata.VERSION
VERIFIED_VERSIONS = ("16.0.1", "16.0.3")
BEFORE = "SAVE_DATA_BEFORE"
EDITED = "SAVE_DATA_EDITED"
MANUAL = "SAVE_DATA_MANUAL"
RAW = "SAVE_DATA_TRANSFER.raw"
ULTRA_TALENT_LEVEL = 60
# The signed JP 16.0.1 and 16.0.3 InstallPacks contain identical DataLocal/resLocal files.
GAME_DATA_HASHES = {
    "DataLocal/drop_chara.csv": "cfc0163d798aa4357767c97e884864c04efedebd954a678bc19f30edb95647f9",
    "DataLocal/nyankoPictureBookData.csv": "84f2eaa977b454de67aba0c7aa521607c062750d583c5c861443d4f7d6a15550",
    "DataLocal/rankGift.csv": "6c4054bafd373a30e1a0ffdae9d8498bea6333a81944946f52057386489e695c",
    "DataLocal/SkillAcquisition.csv": "9bbd7a98bdb4d06ef4f65316141c6aad22c2fbb2054dfea10a441d78a1001106",
    "DataLocal/SkillLevel.csv": "46a79cf149c2a3730afbce189b6b3861e6bacb0335f0fe1582e2758a7572947b",
    "DataLocal/unitbuy.csv": "b062854b5dd5a9372db9a255e2d7c9895c8d68b294b4f18fbc42d343483350a3",
    "DataLocal/unitlimit.csv": "fe20fdfe5805c13699adce4883065c67802ac0e9b5d98d287be8d8aec5275292",
    "resLocal/SkillDescriptions.csv": "8fdcb68b164f7b064bb5d46ec07852e9c43c7041c5e362cfe5e5c42543f1b9dd",
}


def increase_level(save: core.SaveFile, cat: core.Cat, required_total: int) -> None:
    if cat.upgrade.get_total() >= required_total:
        return
    target_base = required_total - cat.upgrade.plus
    helper = core.PowerUpHelper(cat, save)
    helper.upgrade_by(target_base - cat.upgrade.get_base())
    if cat.upgrade.get_base() < target_base:
        raise ValueError(f"Cat {cat.id} could not reach the required total Lv.{required_total}.")


def require_jp_version(save: core.SaveFile) -> str:
    version = save.game_version.to_string()
    if save.cc.get_code() != "jp" or version not in VERIFIED_VERSIONS:
        supported = " or ".join(VERIFIED_VERSIONS)
        raise ValueError(f"Expected JP {supported}; found {save.cc.get_code()} {version}.")
    return version


def max_talents(cat: core.Cat, caps: dict[int, int]) -> int:
    if cat.talents is None:
        cat.talents = []
    existing = {talent.id: talent for talent in cat.talents}
    added = 0
    for ability, level in sorted(caps.items()):
        if ability in existing:
            existing[ability].level = level
        else:
            cat.talents.append(Talent(ability, level))
            added += 1
    return added


def roster_update(original: core.SaveFile) -> tuple[bytes, dict]:
    version = require_jp_version(original)
    before = deepcopy(original.to_dict())
    new_cats, new_report = phone.apply_edits(original, version=version, max_new_cats=True)
    save = core.SaveFile(core.Data(new_cats))
    expected = deepcopy(save.to_dict())
    cats = {cat.id: cat for cat in save.cats.get_all_cats()}
    picture_book = save.cats.read_nyanko_picture_book(save)
    unit_buy = save.cats.read_unitbuy(save)
    talent_data = save.cats.read_talent_data(save)
    if talent_data is None or not core.core_data.get_game_data_getter(save).does_save_version_match(save):
        raise ValueError("Cannot read the matching JP talent tables.")

    total_slots = 0
    counts: Counter[str] = Counter()
    skipped_ids: list[int] = []
    cat_report = {}
    for cat_id, row in sorted(talent_data.cats.skills.items()):
        skills = [skill for skill in row.skills if skill.ability_id > 0]
        total_slots += len(skills)
        cat = cats.get(cat_id)
        if cat is None or not cat.unlocked:
            skipped_ids.append(cat_id)
            continue
        entry = picture_book.get_cat(cat_id)
        limits = unit_buy.get_unit_buy(cat_id)
        if not skills or entry is None or entry.total_forms < 3 or limits is None:
            raise ValueError(f"Cat {cat_id}: invalid talent or form definition.")

        caps = {}
        for skill in skills:
            cap = max(1, skill.max_lv)
            cost = talent_data.get_skill_level(skill.lvid)
            if (skill.limit not in (0, 1) or skill.ability_id in caps or skill.max_lv < 0
                    or cost is None or sum(level > 0 for level in cost.levels) < cap
                    or talent_data.get_skill_name(skill.text_id) is None):
                raise ValueError(f"Cat {cat_id}: invalid talent {skill.ability_id}.")
            caps[skill.ability_id] = cap
        if cat.talents is not None:
            present = Counter(slot.id for slot in cat.talents)
            if any(present[ability] > 1 for ability in caps):
                raise ValueError(f"Cat {cat_id}: duplicate talent records in the save.")

        has_true_form = cat.unlocked_forms >= 3 or cat.current_form >= 2 or cat.fourth_form > 0
        required = 0 if has_true_form else (limits.evolve_level_tf if limits.evolve_level_tf > 0 else 20)
        if any(skill.limit == 1 for skill in skills):
            required = max(required, ULTRA_TALENT_LEVEL)
        if cat_id == 159:
            if limits.evolve_level_ff != 60:
                raise ValueError("Cat 159: unexpected fourth-form level requirement.")
            required = max(required, limits.evolve_level_ff)
        start_level = cat.upgrade.get_base()
        increase_level(save, cat, required)
        counts["levels_raised_for_prerequisites"] += cat.upgrade.get_base() != start_level
        if not has_true_form:
            cat.true_form(save, set_current_form=False)
            counts["third_forms_unlocked"] += 1
        if cat_id == 159 and cat.fourth_form != 2:
            if save.cats.fourth_form_cats(save, [cat], set_current_forms=False) != 1:
                raise ValueError("Cat 159: the picture book did not confirm the fourth form.")

        old_cat = expected["cats"]["cats"][cat_id]
        counts["talent_slots_added"] += max_talents(cat, caps)
        edited = cat.serialize()
        counts["cats_with_talent_changes"] += old_cat["talents"] != edited["talents"]
        counts["owned_cats_with_talents"] += 1
        counts["normal_talents_at_max"] += sum(skill.limit == 0 for skill in skills)
        counts["ultra_talents_at_max"] += sum(skill.limit == 1 for skill in skills)
        if cat_id in (241, 358, 660):
            cat_report[cat_id] = caps
        for key in ("talents", "upgrade", "max_upgrade_level", "catseyes_used", "unlocked_forms", "fourth_form"):
            old_cat[key] = edited[key]

    if (len(talent_data.cats.skills), total_slots) != (193, 1081):
        raise ValueError(f"The talent tables do not match the verified JP {version} catalogue.")
    payload = save.to_data().to_bytes()
    reloaded = core.SaveFile(core.Data(payload))
    after = reloaded.to_dict()
    if after != expected:
        raise ValueError("Round-trip verification failed.")
    outside_cats = sorted(key for key in before if key != "cats" and before[key] != after[key])
    if set(outside_cats) - {"unit_drops", "menu_unlocks"}:
        raise ValueError(f"Unexpected changes to progress: {', '.join(outside_cats)}.")
    if {k: v for k, v in before["cats"].items() if k != "cats"} != {
        k: v for k, v in after["cats"].items() if k != "cats"
    }:
        raise ValueError("Cat collection metadata changed unexpectedly.")

    return payload, {
        "region": "jp", "version": version,
        "talent_catalogue_cats": len(talent_data.cats.skills),
        **{key: counts[key] for key in (
            "owned_cats_with_talents", "normal_talents_at_max", "ultra_talents_at_max",
            "talent_slots_added", "cats_with_talent_changes", "third_forms_unlocked",
            "levels_raised_for_prerequisites",
        )},
        "unowned_talent_cat_ids": skipped_ids,
        "new_cat_levels": new_report["new_cat_levels"],
        "califa_fourth_form_unlocked": cats[159].fourth_form == 2,
        "jp16_talent_levels": cat_report,
        "into_the_future_3_clear": reloaded.story.is_stage_clear(6, 47),
        "changed_save_fields": outside_cats,
        "progress_verified": True,
    }


def receive(session: Path, *, version: str = VERSION) -> bytes:
    print("Enter the transfer codes from the phone whose progress you want to update.")
    transfer_code = input("Transfer code: ").strip()
    pin = input("Confirmation code: ").strip()
    if not re.fullmatch(r"[A-Za-z0-9_-]+", transfer_code) or not re.fullmatch(r"[0-9]+", pin):
        raise ValueError("Enter the phone's transfer code and numeric confirmation code.")
    raw_path = session / RAW
    core.set_transfer_backup_path(core.Path(str(raw_path)))
    handler, _ = core.ServerHandler.from_codes(
        transfer_code, pin, core.CountryCode.from_code("jp"),
        core.GameVersion.from_string(version), print=False,
    )
    if handler is None:
        raise ValueError("The server did not return a save. Check the codes, region and connection.")
    return handler.save_file.to_data().to_bytes()


def check_game_data(game_data: Path, version: str = VERSION) -> None:
    phone.check_cache(game_data, version=version)
    version_root = game_data / "jp" / version
    for name, digest in GAME_DATA_HASHES.items():
        if hashlib.sha256((version_root / name).read_bytes()).hexdigest() != digest:
            raise ValueError(f"JP {version} data differs from the verified release: {name}.")


def recovery_command(session: Path, *, accept_server_account: bool = False) -> str:
    ps_path = str(session).replace("'", "''")
    mode = "recover-progress" if accept_server_account else "recover"
    return f".\\tools\\Run-BrotherLab.cmd {mode} '{ps_path}'"


def find_recovery_session(sessions: Path, *, accept_server_account: bool = False) -> Path:
    matches = [
        folder for version in VERIFIED_VERSIONS for folder in sessions.glob(f"jp-{version}-*")
        if folder.is_dir() and ((folder / BEFORE).is_file() or (folder / RAW).is_file())
    ]
    if len(matches) == 1:
        return matches[0]
    if matches:
        print("Choose the folder from the Session line of the download you want to recover:")
        for session in sorted(matches, key=lambda folder: folder.stat().st_mtime_ns, reverse=True):
            print(recovery_command(session, accept_server_account=accept_server_account))
        raise ValueError("Multiple downloaded backups found. Select the matching session.")
    raise ValueError("No downloaded backup found in the brother sessions.")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lab-root", type=Path, required=True)
    parser.add_argument("--receive-version", choices=VERIFIED_VERSIONS, default=VERSION,
                        help="JP game version currently installed on the phone")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--save", type=Path, help="prepare from an existing original save")
    mode.add_argument("--upload", type=Path, help="request codes for the verified copy in this session")
    mode.add_argument("--upload-progress", type=Path,
                      help="upload the verified copy and accept a server-issued inquiry code")
    mode.add_argument("--upload-manual", type=Path,
                      help="verify and upload a manually edited copy from this session")
    mode.add_argument("--edit", type=Path, help="open a separate copy of this session in the manual editor")
    mode.add_argument("--recover", nargs="?", const=True, type=Path, help="request codes for an original backup")
    mode.add_argument("--recover-progress", nargs="?", const=True, type=Path,
                      help="restore an original backup and accept a server-issued inquiry code")
    parser.add_argument("--bundle", type=Path, help="install JP data from this downloaded APKM or XAPK")
    args = parser.parse_args()
    lab = args.lab_root.resolve()
    sessions = lab / "appdata" / "saves" / "brother"
    game_data = lab / "appdata" / "game_data"

    try:
        with TemporaryDirectory(prefix="bcsfe-lab-roster-") as temp:
            core.set_data_dir_path(core.Path(temp))
            core.set_config_path(core.Path(str(Path(temp) / "config.yaml")))
            core.set_log_path(core.Path(str(Path(temp) / "bcsfe.log")))
            core.set_game_data_path(core.Path(str(game_data)))
            core.core_data.init_data()
            core.core_data.config[core.ConfigKey.UNLOCK_CAT_ON_EDIT] = False
            accept_server_account = any(mode is not None for mode in (
                args.upload_progress, args.upload_manual, args.recover_progress,
            ))
            restoring = args.recover is not None or args.recover_progress is not None
            selected_session = (
                args.upload or args.upload_progress or args.upload_manual or args.edit
                or args.recover or args.recover_progress
            )
            if selected_session is True:
                selected_session = find_recovery_session(sessions, accept_server_account=accept_server_account)
            if selected_session is not None:
                session = selected_session.resolve(strict=True)
                if session.parent != sessions.resolve():
                    raise ValueError("Choose a brother session directory.")
                before = session / BEFORE
                version = VERSION
                manual = session / MANUAL
                if args.edit is not None:
                    version = require_jp_version(phone.read_save(before))
                    check_game_data(game_data, version)
                    if not manual.is_file():
                        payload, _ = transfer.load_phone_copy(
                            session / EDITED, before, expected_version=version, accept_server_account=True,
                        )
                        with manual.open("xb") as file:
                            file.write(payload)
                    transfer.load_phone_copy(manual, before, expected_version=version, accept_server_account=True)
                    editor_data = session / "manual-editor"
                    editor_data.mkdir(exist_ok=True)
                    subprocess.run([
                        sys.executable, "-m", "bcsfe", "--data-dir", str(editor_data),
                        "--game-data-dir", str(game_data), "--input-path", str(manual),
                        "--config-path", str(editor_data / "config.yaml"),
                        "--log-path", str(editor_data / "bcsfe.log"),
                        "--skip-automatic-save-edits",
                    ], check=True)
                    print(f"Manual copy: {manual}")
                    return
                if restoring:
                    if not before.is_file():
                        before = session / RAW
                    candidate = session / "SAVE_DATA_RESTORE"
                    if not candidate.is_file():
                        initial = before.read_bytes()
                        with candidate.open("xb") as file:
                            file.write(initial)
                        if (session / EDITED).is_file():
                            original = core.SaveFile(core.Data(initial))
                            version = require_jp_version(original)
                            _, edited = transfer.load_phone_copy(
                                session / EDITED, before, expected_version=version, accept_server_account=True,
                            )
                            if accept_server_account or edited.inquiry_code == original.inquiry_code:
                                digest = hashlib.sha256(initial).hexdigest() if accept_server_account else None
                                transfer.keep_updated_credentials(candidate, initial, edited, recovery_backup_digest=digest)
                else:
                    candidate = manual if args.upload_manual is not None else session / EDITED
                    report = json.loads((session / "report.json").read_text(encoding="utf-8"))
                    version = require_jp_version(phone.read_save(before))
                    if report.get("progress_verified") is not True or report.get("version") != version:
                        raise ValueError("Choose a session with a verified copy.")
                code, pin = transfer.upload(
                    candidate, before, expected_version=version, upload_managed_items=False,
                    restore_original=restoring, accept_server_account=accept_server_account,
                )
                print("UPLOAD_OK")
                print(f"Transfer Code: {code}\nConfirmation Code: {pin}")
                return

            received = args.save.read_bytes() if args.save is not None else None
            original = core.SaveFile(core.Data(received)) if received is not None else None
            version = require_jp_version(original) if original is not None else args.receive_version
            resume_lab_bcdata.resume(lab, args.bundle, version=version)
            check_game_data(game_data, version)
            sessions.mkdir(parents=True, exist_ok=True)
            session = Path(mkdtemp(prefix=f"jp-{version}-", dir=sessions))
            print(f"Session: {session}", flush=True)
            before = session / BEFORE
            if received is None:
                received = receive(session, version=version)
            before.write_bytes(received)
            if original is None:
                print(f"Original backup saved. Recovery command: {recovery_command(session)}", flush=True)
                original = phone.read_save(before)
                if (session / RAW).is_file():
                    raw = phone.read_save(session / RAW)
                    if phone.state_without_transfer_credentials(raw) != phone.state_without_transfer_credentials(original):
                        raise ValueError("The downloaded backup differs from the server's save after reloading.")
                actual_version = require_jp_version(original)
                if actual_version != version:
                    resume_lab_bcdata.resume(lab, None, version=actual_version)
                    check_game_data(game_data, actual_version)
            payload, report = roster_update(original)
            (session / EDITED).write_bytes(payload)
            report["session"] = str(session)
            (session / "report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
            print(json.dumps(report, indent=2))
            if not report["into_the_future_3_clear"]:
                print("The game displays talents after Into the Future Chapter 3 is cleared.")
            ps_path = str(session).replace("'", "''")
            print(f"Upload command: .\\tools\\Run-BrotherLab.cmd upload '{ps_path}'")
            print("READY")
    except (OSError, UnicodeError, ValueError, BadZipFile, core.SaveError, transfer.TransferError) as error:
        parser.exit(1, f"BCSFE Lab: {error}\n")
    except subprocess.CalledProcessError:
        parser.exit(1, "BCSFE Lab: Data setup failed. See the setup error above.\n")
    except Exception as error:
        parser.exit(1, f"BCSFE Lab: Operation failed ({type(error).__name__}).\n")


if __name__ == "__main__":
    main()
