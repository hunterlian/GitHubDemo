#!/usr/bin/env python3
"""Request transfer codes for a JP Lab save using verified account credentials."""

from __future__ import annotations

import argparse
import hashlib
import os
from pathlib import Path
import sys
from tempfile import NamedTemporaryFile, TemporaryDirectory
from typing import Any

import jwt

from bcsfe import core
from bcsfe.core.server.server_handler import RequestResult


CREDENTIAL_KEYS = ("password", "auth_token")
RECOVERY_BACKUP_KEY = "recovery_backup_sha256"


class TransferError(Exception):
    pass


class ExistingAccountTransfer(core.ServerHandler):
    def __init__(self, save: core.SaveFile, *, accept_server_account: bool = False):
        super().__init__(save, print=False)
        self.original_account = save.inquiry_code
        self.original_ban_message = save.show_ban_message
        self.accept_server_account = accept_server_account

    def create_new_account(self, tries: int = 3) -> bool:
        raise TransferError("AUTH_REJECTED: Existing-account authentication failed.")

    def do_request(self, url: str, dict_data: dict[str, Any]) -> RequestResult:
        result = super().do_request(url, dict_data)
        payload = result.payload
        if payload is None:
            return result
        endpoint = url.removeprefix(self.auth_url)
        password_request = endpoint in ("/v1/user/password", "/v1/users")
        account = payload.get("accountCode")
        if account and account != self.save_file.inquiry_code:
            if self.accept_server_account and endpoint == "/v1/tokens":
                # Let the upstream token flow discard a stale password and refresh it.
                result.payload = None
                return result
            if not (
                self.accept_server_account and password_request
                and self.save_file.inquiry_code == self.original_account
            ):
                raise TransferError(f"ACCOUNT_MISMATCH: Server returned a different account ({endpoint}).")
            if not isinstance(account, str) or not all(
                isinstance(payload.get(key), str) and payload[key]
                for key in ("password", "passwordRefreshToken")
            ):
                raise TransferError("AUTH_REJECTED: The server did not return usable recovery credentials.")
            if result.timestamp is not None:
                self.save_file.energy_penalty_timestamp = int(result.timestamp)
            self.save_file.inquiry_code = account
            self.remove_stored_auth_token()
            self.remove_stored_save_key_data()
        if password_request:
            # BCSFE handles the returned password and refresh token after this call.
            payload.pop("accountCode", None)
        return result

    def validate_auth_token(self, auth_token: str) -> bool:
        try:
            return super().validate_auth_token(auth_token)
        except jwt.InvalidTokenError:
            return False

    def get_auth_token_new(self, password: str) -> str | None:
        token = super().get_auth_token_new(password)
        if token is not None and not self.validate_auth_token(token):
            self.remove_stored_auth_token()
            if self.accept_server_account:
                self.remove_stored_password()
                return None
            raise TransferError("AUTH_TOKEN_INVALID: The returned token could not authenticate this account.")
        return token

    def get_save_key_new(self, auth_token: str) -> dict[str, Any] | None:
        if not self.validate_auth_token(auth_token):
            raise TransferError("AUTH_TOKEN_INVALID: The token does not authenticate the current account.")
        # The authenticated endpoint issues a fresh S3 key. Its path is server-defined.
        result = super().get_save_key_new(auth_token)
        if result is not None:
            key = result.get("key")
            if not isinstance(key, str) or not key.strip():
                self.remove_stored_save_key_data()
                raise TransferError("INVALID_UPLOAD_KEY: The server did not return a usable upload key.")
        return result

    def get_upload_request_form(self, save_key: dict[str, str]) -> core.MultipartForm:
        self.save_file.show_ban_message = self.original_ban_message
        return super().get_upload_request_form(save_key)


def unchanged_state(
    save: core.SaveFile, *, restore_original: bool = False, reassigned: bool = False,
) -> dict:
    state = save.to_dict()
    state.pop("password_refresh_token")
    if not restore_original:
        for key in ("cats", "unit_drops", "menu_unlocks"):
            state.pop(key)
    if reassigned:
        state.pop("inquiry_code")
        state.pop("energy_penalty_timestamp")
    prefixes = tuple(
        core.SaveFile.get_string_identifier(key) + ":"
        for key in (*CREDENTIAL_KEYS, "save_key", RECOVERY_BACKUP_KEY)
    )
    state["order_ids"] = [entry for entry in state["order_ids"] if not entry.startswith(prefixes)]
    return state


def load_phone_copy(
    path: Path,
    backup: Path,
    *,
    expected_version: str = "16.0.1",
    restore_original: bool = False,
    accept_server_account: bool = False,
) -> tuple[bytes, core.SaveFile]:
    if path.samefile(backup):
        raise TransferError("INPUT: Select the Lab phone test copy and a separate original backup.")
    data = path.read_bytes()
    save = core.SaveFile(core.Data(data))
    original_data = backup.read_bytes()
    original = core.SaveFile(core.Data(original_data))
    if save.cc.get_code() != "jp":
        raise TransferError("INPUT: Select a Japanese save.")
    if not restore_original and save.game_version.to_string() != expected_version:
        raise TransferError(f"INPUT: Select the JP {expected_version} Lab phone test copy.")
    reassigned = save.inquiry_code != original.inquiry_code
    if not save.inquiry_code or not original.inquiry_code or (reassigned and not (
        accept_server_account
        and save.get_string(RECOVERY_BACKUP_KEY) == hashlib.sha256(original_data).hexdigest()
    )):
        raise TransferError("ACCOUNT_MISMATCH: The copy and backup must belong to the same account.")
    original_state = unchanged_state(original, restore_original=restore_original, reassigned=reassigned)
    if unchanged_state(save, restore_original=restore_original, reassigned=reassigned) != original_state:
        raise TransferError("INPUT: The copy has other progress differences from the phone backup.")
    return data, save


def keep_updated_credentials(
    path: Path, initial: bytes, session: core.SaveFile, *, recovery_backup_digest: str | None = None,
) -> None:
    copy = core.SaveFile(core.Data(initial))
    changed = copy.password_refresh_token != session.password_refresh_token
    if copy.inquiry_code != session.inquiry_code:
        if recovery_backup_digest is None:
            raise TransferError("ACCOUNT_MISMATCH: Local credentials could not be saved.")
        copy.inquiry_code = session.inquiry_code
        copy.energy_penalty_timestamp = session.energy_penalty_timestamp
        copy.remove_dict(core.ServerHandler.get_save_key_key())
        copy.store_string(RECOVERY_BACKUP_KEY, recovery_backup_digest)
        changed = True
    copy.password_refresh_token = session.password_refresh_token
    for key in CREDENTIAL_KEYS:
        value = session.get_string(key)
        if copy.get_string(key) != value:
            changed = True
            if value is None:
                copy.remove_string(key)
            else:
                copy.store_string(key, value)
    if not changed:
        return

    payload = copy.to_data().to_bytes()
    with NamedTemporaryFile(dir=path.parent, prefix=".phone-transfer-", delete=False) as file:
        temp = Path(file.name)
    try:
        temp.write_bytes(payload)
        if path.read_bytes() != initial:
            raise TransferError("The test copy changed while the transfer was running.")
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def upload(
    path: Path,
    backup: Path,
    *,
    expected_version: str = "16.0.1",
    upload_managed_items: bool = True,
    restore_original: bool = False,
    accept_server_account: bool = False,
) -> tuple[str, str]:
    initial, save = load_phone_copy(
        path, backup, expected_version=expected_version, restore_original=restore_original,
        accept_server_account=accept_server_account,
    )
    recovery_backup_digest = hashlib.sha256(backup.read_bytes()).hexdigest() if accept_server_account else None
    previously_reassigned = bool(save.get_string(RECOVERY_BACKUP_KEY))
    save.remove_string(RECOVERY_BACKUP_KEY)
    transfer = ExistingAccountTransfer(save, accept_server_account=accept_server_account)
    authenticated = False
    try:
        print("Authenticating saved account...", flush=True)
        if transfer.get_auth_token() is None:
            raise TransferError("AUTH_REJECTED: Existing-account authentication failed.")
        authenticated = True
        if previously_reassigned or save.inquiry_code != transfer.original_account:
            print("Working copy is using the inquiry code issued by the server.", flush=True)
        label = "original backup" if restore_original else "Lab phone test copy"
        print(f"Requesting transfer codes for the {label} (JP {save.game_version})...", flush=True)
        codes = transfer.get_codes(upload_managed_items=upload_managed_items, tries=1)
        if codes is None:
            raise TransferError("NO_CODES: No transfer codes were received after authentication.")
        return codes
    finally:
        if authenticated or save.inquiry_code == transfer.original_account:
            try:
                keep_updated_credentials(path, initial, save, recovery_backup_digest=recovery_backup_digest)
            except (TransferError, OSError, core.SaveError):
                print("BCSFE Lab: Could not retain updated credentials in the working copy.", file=sys.stderr)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("save", type=Path, help="prepared Lab phone test copy")
    parser.add_argument("--before", type=Path, required=True, help="the original phone backup")
    args = parser.parse_args()

    try:
        with TemporaryDirectory(prefix="bcsfe-lab-transfer-") as temp:
            core.set_data_dir_path(core.Path(temp))
            core.set_config_path(core.Path(str(Path(temp) / "config.yaml")))
            core.set_log_path(core.Path(str(Path(temp) / "bcsfe.log")))
            core.core_data.init_data()
            transfer_code, confirmation_code = upload(args.save.resolve(), args.before.resolve())
    except TransferError as error:
        parser.exit(1, f"BCSFE Lab: {error}\n")
    except Exception as error:
        parser.exit(1, f"BCSFE Lab: Transfer failed ({type(error).__name__}).\n")
    print("UPLOAD_OK")
    print(f"Transfer Code: {transfer_code}")
    print(f"Confirmation Code: {confirmation_code}")


if __name__ == "__main__":
    main()
