# 貓咪大戰爭 Lab Android v0.1 — 開發測試版

這是先前 Windows BCSFE Lab v0.1.0 的 Android **原始碼／可建置專案**，並非可直接安裝的 APK。它使用 Android 原生 Java 介面 + Chaquopy Python 3.13 執行既有 BCSFE 核心。此專案的原始碼已產出、Python 靜態／離線單元測試已檢查，但 **尚未真正完成 APK 編譯／Android 手機安裝、接收、上傳端到端測試**。請勿將開發版當成可放心操作正式主帳號的工具。

## 已實作／尚待實機驗證

1. 自己與弟弟的工作階段分離、列表管理、檢視 JP 16.0.1/16.0.3 存檔資訊。
2. 用 Android 系統檔案選擇器匯入自己合法取得的 `SAVE_DATA` / `.raw`；原始備份永不直接覆寫。
3. 使用 Windows 版已驗證的 JP `game_data` ZIP，檢查 SHA-256，離線建立「已持有角色的本能補滿／已驗證新增角色」修改副本（與 Windows 相同邏輯），再存出 `.raw`。
4. **實驗性**網路接收／上傳／原始備份還原操作，沿用舊版 Lab 的伺服器流程，所有上傳都要使用者手動確認，回傳引繼碼不會寫入 App 的一般紀錄。**尚未驗證 Android 端的伺服器相容性，務必以可還原測試帳號先試**。
5. 除了你手機與遊戲官方服務通訊，不需要自建後端伺服器。Android App 沙盒不允許它隨意讀取其他 App 的私人檔案，也不需要 Root。

## 編譯成 APK

**方法 A：Android Studio**

1. 在電腦安裝 Android Studio（有 Java JDK 17 與 Android SDK 平台 35）；安裝 Python **3.13**，並放進 PATH。
2. 用 Android Studio 開啟本 ZIP 解壓後的資料夾，允許 Gradle 同步、下載相依套件。使用可連網環境。
3. 選擇 `Build > Build APK(s)`。完成後 APK 在 `app/build/outputs/apk/debug/app-debug.apk`。
4. 把 `app-debug.apk` 傳到 Android 手機，開啟安裝。套件 ID：`tw.battlecats.lab`；目前只打包 ARM64（目前一般 Android 手機）。

**方法 B：GitHub Actions**

本專案提供 `.github/workflows/build-apk.yml`，如果你把**完整原始碼**放到自己 GitHub 儲存庫（建議 private），在 GitHub `Actions` 頁面手動執行 `Build BattleCats Lab APK`，成功後下載 `BattleCatsLab-Android-debug` artifact，即可得到 APK。這個工作流程**尚未在 GitHub runner 跑過**。

注意：debug APK 的簽章一般由建置環境臨時產生，未來換電腦／GitHub runner 時，可能無法直接覆蓋安裝。正式版須改用自己保管的**固定簽章金鑰**，才能保留 App 的本機資料進行升級。改版本時只換新 APK／更新簽章，不開放從不可信 ZIP 執行任意 Python 程式碼。

## 手機上的步驟

1. 打開 Lab，選擇「我的帳號」或「弟弟的帳號」，確認 JP 版本。
2. 從遊戲引繼畫面取得合法的引繼碼與確認碼，**或**先選擇先前已存好的本機 `.raw` 備份。建議先從匯入備份開始測試。
3. 如果要使用已驗證的「全本能」預設，先從**已正常完成初始化**的 Windows BCSFE Lab 匯出相同版本遊戲資料：

   ```powershell
   py -3 scripts\export_game_cache.py --lab-root "$env:USERPROFILE\Documents\BCSFE-Lab" --version 16.0.3 --output JP-16.0.3-Cache.zip
   ```

   然後把 ZIP 傳到手機，在本 App 用「匯入 JP 16.0.x 資料 ZIP」匯入。**此 APK 原始碼包不含遊戲 APK、遊戲資料表及任何玩家存檔。**
4. 選擇工作階段，先點「檢查原始存檔」，再按「套用 JP 16.0.x 已驗證全本能預設」。此按鈕只處理 Windows 版原已驗證的變更項目，**不是任意角色自由編輯器**。
5. 透過「匯出修改副本」將結果另存到手機（匯出的 `.raw` 並不等同能直接被未 Root 的遊戲讀取）。
6. 如果要上傳，請先確認 Android 版在測試帳號驗證成功，才點「上傳修改副本並取得引繼碼」，手動在遊戲內輸入回傳的兩組碼。

## 原始資料保護與限制

- App 的私有資料位於 Android app-internal files；解除安裝會**刪除**工作階段備份，必須另外手動匯出「原始備份」到安全位置保存。
- 不會自動覆寫原始 SAVE_DATA，也不會嘗試突破 Android 沙盒／Root。
- 如果遊戲新版更換存檔格式、角色表、引繼 API 或帳號驗證，必須重新驗證和更新。Windows 與 Android 可共用核心邏輯，但各平台建置產物不同。
- 測試版可能遭遇遊戲條款／封號與轉移失敗風險；請勿先上主帳號。
- 截圖、剪貼簿都可能暴露引繼碼。App 不會把它們寫到 `meta.json`、`report.json` 或工作紀錄，但會在原始存檔備份保留遊戲本身的驗證相關資訊（復原所必需）。
- 第一個 APK 不追求漂亮 UI 或批次自由編輯；先驗證「Android Python 能啟動 → Android 匯入/解析 → 快取驗證 → 離線修改 → 真實官方接收/上傳」。

## 開源

基於 fieryhenry / BCSFE-Python（GPL-3.0-or-later），完整衍生原始碼保留在 `app/src/main/python/bcsfe`、`tools` 與 `LICENSE`。官方遊戲內容、APK、帳號資料不在此專案內。
