"""Export your EXISTING verified JP cache for the Android Lab (no game data included here)."""
import argparse
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--lab-root', required=True, type=Path)
    ap.add_argument('--version', choices=['16.0.1','16.0.3'], default='16.0.3')
    ap.add_argument('--output', type=Path, default=Path('BC-Lab-JP-Cache.zip'))
    args = ap.parse_args()
    folder = args.lab_root / 'appdata' / 'game_data' / 'jp' / args.version
    if not (folder / 'downloaded').is_file():
        ap.error(f'已驗證的資料快取不存在：{folder}')
    if not (folder / 'DataLocal' / 'unitbuy.csv').is_file():
        ap.error('缺少資料快取 DataLocal/unitbuy.csv')
    args.output.parent.mkdir(parents=True, exist_ok=True)
    count = 0
    with ZipFile(args.output, 'x', compression=ZIP_DEFLATED, compresslevel=6) as z:
        for path in sorted(folder.rglob('*')):
            if path.is_file() and not path.is_symlink():
                name = 'jp/' + args.version + '/' + path.relative_to(folder).as_posix()
                z.write(path, name)
                count += 1
    print(f'完成：{args.output.resolve()}，{count} 個檔案。\n請將 ZIP 傳到手機並在 Lab 匯入。')

if __name__ == '__main__':
    main()
