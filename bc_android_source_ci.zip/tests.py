from pathlib import Path
import json
import tempfile
import unittest
from zipfile import ZipFile
from unittest.mock import patch
import sys
sys.path.insert(0, str(Path(__file__).parent / 'app/src/main/python'))
import mobile_bridge as m

class BridgeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.home = self.temp.name

    def test_profile_and_session_validation(self):
        with self.assertRaises(ValueError): m.list_sessions('../mine', self.home)
        with self.assertRaises(ValueError): m.inspect('../../other', 'mine', self.home)
        self.assertEqual(json.loads(m.list_sessions('mine', self.home)), [])

    def test_invalid_save_stays_unmodified(self):
        path = Path(self.home)/'fake.raw'
        path.write_bytes(b'not a valid save')
        with self.assertRaises(Exception): m.import_save(str(path),'mine',self.home)
        self.assertEqual(path.read_bytes(), b'not a valid save')
        self.assertEqual(json.loads(m.list_sessions('mine', self.home)), [])

    def test_zip_traversal_rejected(self):
        file = Path(self.home) / 'bad.zip'
        with ZipFile(file,'w') as z:
            z.writestr('jp/16.0.3/../../../evil.txt', 'bad')
        with self.assertRaises(ValueError): m.import_game_data_zip(str(file), self.home)
        self.assertFalse((Path(self.home) / 'evil.txt').exists())

    def test_zip_unknown_version_rejected(self):
        file = Path(self.home) / 'wrong.zip'
        with ZipFile(file,'w') as z:
            z.writestr('jp/16.1.0/DataLocal/unitbuy.csv', 'test')
        with self.assertRaises(ValueError): m.import_game_data_zip(str(file), self.home)

    def test_receive_rejects_bad_input_without_network(self):
        with self.assertRaises(ValueError): m.receive('ab', '1x', '16.0.3','mine',self.home)
        with self.assertRaises(ValueError): m.receive('ab', '12', '16.1.0','mine',self.home)

    def test_real_bcsfe_synthetic_round_trip(self):
        root = Path(self.home)
        with m._engine(root) as core:
            s = core.SaveFile(cc=core.CountryCode.from_code('jp'), gv=core.GameVersion.from_string('16.0.3'))
            s.catfood = 197
            s.xp = 123456
            s.np = 999
            original = s.to_data().to_bytes()
        source = root / 'test_SAVE_DATA'
        source.write_bytes(original)
        response = json.loads(m.import_save(str(source), 'mine', self.home))
        sid = response['session']
        state = json.loads(m.inspect(sid, 'mine', self.home))
        self.assertEqual((state['region'], state['version']), ('jp', '16.0.3'))
        self.assertEqual((state['catfood'], state['xp'], state['np']), (197, 123456, 999))
        self.assertEqual(Path(m.export_path(sid, 'mine', self.home, False)).read_bytes(), original)
        self.assertEqual(source.read_bytes(), original)
        self.assertEqual(json.loads(m.list_sessions('brother', self.home)), [])

    def test_source_has_no_known_user_secrets(self):
        root = Path(__file__).parent
        self.assertTrue((root/'app/src/main/python/bcsfe').is_dir())
        self.assertTrue((root/'LICENSE').is_file())

if __name__ == '__main__': unittest.main()
